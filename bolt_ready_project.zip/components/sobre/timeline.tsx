import { CheckCircle } from "lucide-react"

export function Timeline() {
  const milestones = [
    {
      year: "2009",
      title: "Fundação",
      description: "Início das operações com foco em sistemas web personalizados para pequenas empresas.",
    },
    {
      year: "2012",
      title: "Expansão",
      description: "Ampliação da equipe e portfólio, atendendo médias e grandes empresas em todo Brasil.",
    },
    {
      year: "2016",
      title: "Inovação",
      description: "Adoção de tecnologias cloud e metodologias ágeis, revolucionando nossa entrega.",
    },
    {
      year: "2020",
      title: "Transformação Digital",
      description: "Liderança em projetos de transformação digital durante a pandemia.",
    },
    {
      year: "2024",
      title: "Excelência",
      description: "Mais de 500 clientes ativos e 98% de taxa de satisfação consolidam nossa posição no mercado.",
    },
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-blue-50 via-white to-cyan-50">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Nossa Trajetória</h2>
          <p className="text-xl text-gray-600">Uma história de crescimento, inovação e sucesso</p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="relative">
            {/* Timeline line */}
            <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-gradient-to-b from-blue-600 to-cyan-500"></div>

            {/* Milestones */}
            {milestones.map((milestone, index) => (
              <div key={index} className="relative mb-12 last:mb-0">
                <div
                  className={`flex flex-col md:flex-row items-center gap-8 ${
                    index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                  }`}
                >
                  {/* Content */}
                  <div className="flex-1 bg-white rounded-2xl p-8 shadow-lg">
                    <div className="flex items-center gap-2 mb-4">
                      <CheckCircle className="text-blue-600" size={24} />
                      <span className="text-2xl font-bold text-blue-600">{milestone.year}</span>
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-3">{milestone.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{milestone.description}</p>
                  </div>

                  {/* Dot */}
                  <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 w-6 h-6 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-full border-4 border-white shadow-lg"></div>

                  {/* Spacer */}
                  <div className="flex-1 hidden md:block"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
