import { Target, Heart, Lightbulb, Shield } from "lucide-react"

export function Values() {
  const values = [
    {
      icon: Target,
      title: "Missão",
      description:
        "Desenvolver soluções tecnológicas inovadoras que transformem processos empresariais, aumentem a eficiência e gerem valor real para nossos clientes.",
      color: "from-blue-500 to-cyan-500",
    },
    {
      icon: Heart,
      title: "Visão",
      description:
        "Ser a empresa de referência em soluções tecnológicas personalizadas, reconhecida pela excelência, inovação e compromisso com o sucesso dos nossos clientes.",
      color: "from-cyan-500 to-blue-500",
    },
    {
      icon: Lightbulb,
      title: "Inovação",
      description:
        "Buscamos constantemente novas tecnologias e metodologias para oferecer as melhores soluções, sempre à frente das tendências do mercado.",
      color: "from-purple-500 to-pink-500",
    },
    {
      icon: Shield,
      title: "Compromisso",
      description:
        "Nosso compromisso é com a qualidade, prazos e transparência. Construímos relações duradouras baseadas em confiança e resultados.",
      color: "from-pink-500 to-purple-500",
    },
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Nossos Valores</h2>
          <p className="text-xl text-gray-600">Princípios que guiam nossa jornada e definem quem somos como empresa</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {values.map((value, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-gray-50 to-white rounded-2xl p-8 hover:shadow-lg transition-all border border-gray-100"
            >
              <div
                className={`w-16 h-16 bg-gradient-to-br ${value.color} rounded-2xl flex items-center justify-center mb-6`}
              >
                <value.icon className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">{value.title}</h3>
              <p className="text-gray-600 leading-relaxed">{value.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
