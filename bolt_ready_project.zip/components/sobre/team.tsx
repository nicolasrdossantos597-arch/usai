import { Linkedin, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Team() {
  const team = [
    {
      name: "Carlos Silva",
      role: "CEO & Fundador",
      bio: "Especialista em gestão de TI com 20+ anos de experiência",
      image: "/ceo-portrait.png",
    },
    {
      name: "Ana Costa",
      role: "CTO",
      bio: "Arquiteta de soluções com expertise em cloud e microserviços",
      image: "/professional-cto-woman-portrait.jpg",
    },
    {
      name: "Pedro Santos",
      role: "Head de Desenvolvimento",
      bio: "Desenvolvedor full-stack apaixonado por criar soluções inovadoras",
      image: "/professional-developer-portrait.png",
    },
    {
      name: "Maria Oliveira",
      role: "Gerente de Projetos",
      bio: "Especialista em metodologias ágeis e gestão de equipes",
      image: "/professional-manager-woman-portrait.jpg",
    },
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Conheça Nossa Equipe</h2>
          <p className="text-xl text-gray-600">
            Profissionais experientes e apaixonados por tecnologia, dedicados ao seu sucesso
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
          {team.map((member, index) => (
            <div key={index} className="group">
              <div className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all">
                <div className="aspect-square overflow-hidden bg-gradient-to-br from-gray-100 to-gray-200">
                  <img
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-1">{member.name}</h3>
                  <div className="text-blue-600 font-medium mb-3">{member.role}</div>
                  <p className="text-gray-600 text-sm leading-relaxed mb-4">{member.bio}</p>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                      <Linkedin size={16} />
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                      <Mail size={16} />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
