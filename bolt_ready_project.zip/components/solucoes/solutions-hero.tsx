export function SolutionsHero() {
  return (
    <section className="pt-32 pb-20 bg-gradient-to-br from-blue-50 via-white to-cyan-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Soluções{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-cyan-500">
              Personalizadas
            </span>
          </h1>
          <p className="text-xl text-gray-600 leading-relaxed">
            Desenvolvemos tecnologias sob medida para transformar desafios em oportunidades de crescimento. Cada solução
            é pensada especificamente para as necessidades do seu negócio.
          </p>
        </div>
      </div>
    </section>
  )
}
