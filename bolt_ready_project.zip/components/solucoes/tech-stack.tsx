export function TechStack() {
  const technologies = [
    { name: "React", category: "Frontend" },
    { name: "Next.js", category: "Framework" },
    { name: "TypeScript", category: "Language" },
    { name: "Node.js", category: "Backend" },
    { name: "Python", category: "Backend" },
    { name: "PostgreSQL", category: "Database" },
    { name: "MongoDB", category: "Database" },
    { name: "AWS", category: "Cloud" },
    { name: "Docker", category: "DevOps" },
    { name: "Kubernetes", category: "DevOps" },
    { name: "React Native", category: "Mobile" },
    { name: "Flutter", category: "Mobile" },
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Tecnologias que Usamos</h2>
          <p className="text-xl text-gray-600">Stack moderno e robusto para garantir performance e escalabilidade</p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {technologies.map((tech, index) => (
              <div
                key={index}
                className="bg-gradient-to-br from-gray-50 to-white rounded-xl p-6 text-center hover:shadow-lg transition-all border border-gray-100"
              >
                <div className="text-lg font-bold text-gray-900 mb-1">{tech.name}</div>
                <div className="text-sm text-blue-600">{tech.category}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
