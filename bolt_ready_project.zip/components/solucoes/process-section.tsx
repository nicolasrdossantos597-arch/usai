import { Search, Lightbulb, Code2, Rocket, HeadphonesIcon } from "lucide-react"

export function ProcessSection() {
  const steps = [
    {
      icon: Search,
      title: "Análise",
      description: "Entendemos profundamente seu negócio, desafios e objetivos para criar a solução ideal.",
    },
    {
      icon: Lightbulb,
      title: "Planejamento",
      description: "Desenvolvemos a estratégia, arquitetura e roadmap detalhado do projeto.",
    },
    {
      icon: Code2,
      title: "Desenvolvimento",
      description: "Codificação ágil com entregas incrementais e testes contínuos de qualidade.",
    },
    {
      icon: Rocket,
      title: "Deploy",
      description: "Lançamento estruturado com migração de dados, testes e treinamento da equipe.",
    },
    {
      icon: HeadphonesIcon,
      title: "Suporte",
      description: "Acompanhamento contínuo, manutenções e evoluções conforme necessário.",
    },
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-blue-50 via-white to-cyan-50">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Nosso Processo</h2>
          <p className="text-xl text-gray-600">Metodologia ágil e transparente do início ao fim do projeto</p>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                <div className="bg-white rounded-2xl p-6 text-center hover:shadow-lg transition-shadow h-full">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <step.icon className="text-white" size={24} />
                  </div>
                  <div className="text-sm font-bold text-blue-600 mb-2">Etapa {index + 1}</div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">{step.title}</h3>
                  <p className="text-sm text-gray-600 leading-relaxed">{step.description}</p>
                </div>
                {/* Arrow */}
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 -right-2 transform translate-x-1/2 -translate-y-1/2 text-blue-600">
                    →
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
