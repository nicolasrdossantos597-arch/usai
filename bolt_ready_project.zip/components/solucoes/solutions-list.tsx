import {
  Code,
  Database,
  Cloud,
  Smartphone,
  BarChart,
  ShoppingCart,
  Users,
  Lock,
  Workflow,
  Bot,
  Cpu,
  Globe,
} from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export function SolutionsList() {
  const solutions = [
    {
      icon: Code,
      title: "Sistemas Web Personalizados",
      description:
        "Desenvolvimento de sistemas web sob medida para automatizar e otimizar processos empresariais, com interfaces intuitivas e alta performance.",
      features: ["Arquitetura escalável", "Design responsivo", "Integrações API", "Painéis de controle"],
      color: "from-blue-500 to-cyan-500",
    },
    {
      icon: Smartphone,
      title: "Aplicativos Mobile",
      description:
        "Apps nativos e híbridos para iOS e Android que conectam sua empresa aos clientes de forma inovadora e eficiente.",
      features: ["UX otimizada", "Performance nativa", "Push notifications", "Offline-first"],
      color: "from-cyan-500 to-blue-500",
    },
    {
      icon: ShoppingCart,
      title: "E-commerce Completo",
      description:
        "Plataformas de vendas online robustas com gestão completa de produtos, pedidos, pagamentos e logística integrada.",
      features: ["Checkout otimizado", "Múltiplos pagamentos", "Gestão de estoque", "Marketplace"],
      color: "from-purple-500 to-pink-500",
    },
    {
      icon: BarChart,
      title: "Business Intelligence",
      description:
        "Dashboards e relatórios inteligentes que transformam dados em insights estratégicos para tomada de decisões.",
      features: ["Visualizações interativas", "Análises preditivas", "KPIs em tempo real", "Exportação de dados"],
      color: "from-pink-500 to-purple-500",
    },
    {
      icon: Database,
      title: "Gestão de Dados",
      description:
        "Soluções completas para armazenamento, processamento e análise de grandes volumes de dados com segurança.",
      features: ["Data warehousing", "ETL automatizado", "Backup redundante", "Compliance"],
      color: "from-green-500 to-emerald-500",
    },
    {
      icon: Cloud,
      title: "Cloud Computing",
      description:
        "Migração e gerenciamento de infraestrutura em nuvem para redução de custos e maior flexibilidade operacional.",
      features: ["AWS/Azure/GCP", "Auto-scaling", "Alta disponibilidade", "Monitoramento"],
      color: "from-emerald-500 to-green-500",
    },
    {
      icon: Users,
      title: "CRM & ERP",
      description:
        "Sistemas integrados para gestão de relacionamento com clientes e planejamento de recursos empresariais.",
      features: ["Gestão de vendas", "Controle financeiro", "Automação marketing", "Relatórios"],
      color: "from-orange-500 to-red-500",
    },
    {
      icon: Lock,
      title: "Segurança & Compliance",
      description:
        "Implementação de protocolos de segurança, autenticação avançada e conformidade com LGPD e outras regulações.",
      features: ["Criptografia", "2FA/MFA", "Auditoria", "LGPD compliance"],
      color: "from-red-500 to-orange-500",
    },
    {
      icon: Workflow,
      title: "Automação de Processos",
      description:
        "RPA e automações inteligentes que eliminam tarefas repetitivas e aumentam a produtividade das equipes.",
      features: ["Workflows customizados", "Integração sistemas", "Notificações", "Aprovações digitais"],
      color: "from-indigo-500 to-blue-500",
    },
    {
      icon: Bot,
      title: "Chatbots & IA",
      description:
        "Assistentes virtuais inteligentes para atendimento automatizado e personalizado 24/7 aos seus clientes.",
      features: ["NLP avançado", "Multicanal", "Aprendizado contínuo", "Integrações"],
      color: "from-violet-500 to-purple-500",
    },
    {
      icon: Cpu,
      title: "IoT & Integração",
      description:
        "Conecte dispositivos e sistemas para criar ecossistemas inteligentes e automatizados na sua empresa.",
      features: ["Sensores IoT", "Edge computing", "Dashboards real-time", "Alertas inteligentes"],
      color: "from-teal-500 to-cyan-500",
    },
    {
      icon: Globe,
      title: "APIs & Integrações",
      description:
        "Desenvolvimento de APIs RESTful e integrações entre sistemas para criar fluxos de dados eficientes.",
      features: ["REST/GraphQL", "Webhooks", "Documentação", "Rate limiting"],
      color: "from-sky-500 to-blue-500",
    },
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {solutions.map((solution, index) => (
            <div
              key={index}
              className="group bg-gradient-to-br from-gray-50 to-white rounded-2xl p-8 hover:shadow-2xl transition-all border border-gray-100"
            >
              <div
                className={`w-16 h-16 bg-gradient-to-br ${solution.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}
              >
                <solution.icon className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">{solution.title}</h3>
              <p className="text-gray-600 leading-relaxed mb-6">{solution.description}</p>
              <ul className="space-y-2 mb-6">
                {solution.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                    <div className={`w-1.5 h-1.5 rounded-full bg-gradient-to-r ${solution.color}`}></div>
                    {feature}
                  </li>
                ))}
              </ul>
              <Link href="/contato">
                <Button
                  variant="outline"
                  className="w-full bg-transparent group-hover:bg-blue-600 group-hover:text-white group-hover:border-blue-600 transition-all"
                >
                  Solicitar Orçamento
                </Button>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
