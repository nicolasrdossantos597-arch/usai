"use client"

export function ClientLogos() {
  const logos = [
    "Tech Innovations",
    "Loja Virtual Plus",
    "Clínica Saúde Total",
    "Empresa Alpha",
    "Beta Solutions",
    "Gamma Corp",
    "Delta Systems",
    "Epsilon Group",
    "Zeta Industries",
  ]

  return (
    <section className="py-16 bg-white border-y border-gray-100">
      <div className="container mx-auto px-4">
        <p className="text-center text-sm text-gray-500 mb-8 uppercase tracking-wider">
          Empresas que confiam em nossas soluções
        </p>

        <div className="relative overflow-hidden">
          <div className="flex animate-scroll">
            {[...logos, ...logos].map((logo, index) => (
              <div key={index} className="flex-shrink-0 mx-8 flex items-center justify-center">
                <div className="px-8 py-4 bg-gray-50 rounded-lg border border-gray-200 hover:border-blue-300 transition-colors">
                  <span className="text-gray-600 font-semibold whitespace-nowrap">{logo}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes scroll {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }
        .animate-scroll {
          animation: scroll 30s linear infinite;
        }
        .animate-scroll:hover {
          animation-play-state: paused;
        }
      `}</style>
    </section>
  )
}
