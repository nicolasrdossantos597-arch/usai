import { Award, HeadphonesIcon, Shield, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function WhyChooseUs() {
  const reasons = [
    {
      icon: Award,
      title: "15+ Anos de Experiência",
      description: "Expertise consolidada em desenvolvimento de sistemas corporativos.",
    },
    {
      icon: Users,
      title: "Equipe Especializada",
      description: "Profissionais certificados e altamente qualificados.",
    },
    {
      icon: HeadphonesIcon,
      title: "Suporte Premium 24/7",
      description: "Atendimento rápido e eficiente sempre que você precisar.",
    },
    {
      icon: Shield,
      title: "Garantia de Qualidade",
      description: "Compromisso com excelência e satisfação do cliente.",
    },
  ]

  return (
    <section className="py-24 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Por que Escolher a UAI Sistemas?</h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Somos mais que um fornecedor, somos seu parceiro de transformação digital
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {reasons.map((reason, index) => (
            <div key={index} className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <reason.icon size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2">{reason.title}</h3>
              <p className="text-gray-300">{reason.description}</p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Link href="/sobre">
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-gray-900 px-8 py-6 text-lg rounded-full"
            >
              Conheça Nossa História
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
