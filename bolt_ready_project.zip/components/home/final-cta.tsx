import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight, MessageCircle } from "lucide-react"

export function FinalCTA() {
  return (
    <section className="py-24 bg-gradient-to-br from-blue-600 via-cyan-500 to-blue-700 text-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full filter blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full filter blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Pronto para Transformar Seu Negócio?</h2>
          <p className="text-xl md:text-2xl mb-10 text-blue-50">
            Agende uma demonstração gratuita e descubra como podemos ajudar sua empresa a crescer com tecnologia.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/contato">
              <Button
                size="lg"
                className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-6 text-lg rounded-full shadow-xl"
              >
                Solicitar Demonstração
                <ArrowRight className="ml-2" size={20} />
              </Button>
            </Link>
            <a href="https://wa.me/5531999999999" target="_blank" rel="noopener noreferrer">
              <Button
                size="lg"
                variant="outline"
                className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-6 text-lg rounded-full"
              >
                <MessageCircle className="mr-2" size={20} />
                Falar no WhatsApp
              </Button>
            </a>
          </div>

          <p className="text-sm text-blue-100 mt-8">Resposta em até 2 horas úteis • Sem compromisso</p>
        </div>
      </div>
    </section>
  )
}
