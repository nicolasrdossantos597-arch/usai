import { Calendar, MessageSquare, Rocket, Settings } from "lucide-react"

export function HowItWorks() {
  const steps = [
    {
      icon: Calendar,
      title: "Agende uma Conversa",
      description: "Entre em contato e agende uma reunião gratuita para entender suas necessidades.",
    },
    {
      icon: Settings,
      title: "Análise e Planejamento",
      description: "Nossa equipe analisa seu negócio e cria uma solução personalizada.",
    },
    {
      icon: Rocket,
      title: "Desenvolvimento e Implementação",
      description: "Desenvolvemos e implementamos o sistema com acompanhamento total.",
    },
    {
      icon: MessageSquare,
      title: "Suporte Contínuo",
      description: "Oferecemos suporte 24/7 e melhorias constantes no sistema.",
    },
  ]

  return (
    <section className="py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Como Funciona</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Processo simples e transparente do primeiro contato até o suporte contínuo
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              {/* Connector line */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-16 left-1/2 w-full h-0.5 bg-gradient-to-r from-blue-600 to-cyan-500"></div>
              )}

              <div className="relative bg-white rounded-2xl p-8 shadow-sm hover:shadow-lg transition-shadow text-center">
                {/* Step number */}
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                  {index + 1}
                </div>

                <div className="w-16 h-16 bg-gradient-to-br from-blue-100 to-cyan-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <step.icon className="text-blue-600" size={32} />
                </div>

                <h3 className="text-xl font-bold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600 leading-relaxed">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
