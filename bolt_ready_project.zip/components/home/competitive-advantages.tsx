import { CheckCircle2 } from "lucide-react"

export function CompetitiveAdvantages() {
  const advantages = [
    "Soluções 100% personalizadas para seu negócio",
    "Implementação rápida em até 30 dias",
    "Integração com sistemas existentes",
    "Treinamento completo da equipe",
    "Atualizações e melhorias contínuas",
    "ROI comprovado em até 6 meses",
    "Tecnologia de ponta e escalável",
    "Sem custos ocultos ou surpresas",
  ]

  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Vantagens Competitivas</h2>
            <p className="text-xl text-gray-600">O que nos torna diferentes no mercado</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {advantages.map((advantage, index) => (
              <div key={index} className="flex items-start gap-3 p-4 rounded-xl hover:bg-blue-50 transition-colors">
                <CheckCircle2 className="text-green-500 flex-shrink-0 mt-1" size={24} />
                <span className="text-lg text-gray-700">{advantage}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
