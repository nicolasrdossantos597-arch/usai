import { Quote, Star } from "lucide-react"

export function Testimonials() {
  const testimonials = [
    {
      name: "Carlos Silva",
      role: "CEO - Tech Innovations",
      content:
        "A UAI Sistemas transformou completamente nossa operação. O sistema é intuitivo, rápido e nosso time adorou!",
      rating: 5,
    },
    {
      name: "Maria Santos",
      role: "Diretora - Loja Virtual Plus",
      content: "Aumentamos nossas vendas em 200% após a implementação. Superou todas as expectativas!",
      rating: 5,
    },
    {
      name: "Dr. João Oliveira",
      role: "Diretor - Clínica Saúde Total",
      content: "Suporte excepcional e sistema que realmente entende as necessidades do setor de saúde.",
      rating: 5,
    },
  ]

  return (
    <section className="py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">O que Nossos Clientes Dizem</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Depoimentos reais de empresas que transformaram seus negócios
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-sm hover:shadow-lg transition-shadow relative">
              <Quote className="absolute top-6 right-6 text-blue-100" size={48} />

              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="fill-yellow-400 text-yellow-400" size={18} />
                ))}
              </div>

              <p className="text-gray-700 mb-6 leading-relaxed italic">"{testimonial.content}"</p>

              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-full flex items-center justify-center text-white font-bold">
                  {testimonial.name.charAt(0)}
                </div>
                <div>
                  <div className="font-bold text-gray-900">{testimonial.name}</div>
                  <div className="text-sm text-gray-500">{testimonial.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
