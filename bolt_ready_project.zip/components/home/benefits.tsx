import { BarChart3, Clock, DollarSign, Lock, Smartphone, Zap } from "lucide-react"

export function Benefits() {
  const benefits = [
    {
      icon: Zap,
      title: "Automação Inteligente",
      description: "Elimine tarefas repetitivas e foque no que realmente importa para seu negócio.",
    },
    {
      icon: BarChart3,
      title: "Decisões Baseadas em Dados",
      description: "Relatórios e dashboards em tempo real para tomada de decisões estratégicas.",
    },
    {
      icon: Clock,
      title: "Economia de Tempo",
      description: "Reduza até 70% do tempo gasto em processos manuais e burocráticos.",
    },
    {
      icon: DollarSign,
      title: "Redução de Custos",
      description: "Otimize recursos e reduza custos operacionais em até 50%.",
    },
    {
      icon: Smartphone,
      title: "Acesso em Qualquer Lugar",
      description: "Sistemas responsivos que funcionam perfeitamente em qualquer dispositivo.",
    },
    {
      icon: Lock,
      title: "Segurança Máxima",
      description: "Proteção de dados com criptografia e backup automático.",
    },
  ]

  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Benefícios Reais para Seu Negócio</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Resultados comprovados que transformam a forma como sua empresa opera
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="group p-8 rounded-2xl bg-gradient-to-br from-gray-50 to-white border border-gray-200 hover:border-blue-300 hover:shadow-xl transition-all duration-300"
            >
              <div className="w-14 h-14 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-xl flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                <benefit.icon className="text-white" size={28} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{benefit.title}</h3>
              <p className="text-gray-600 leading-relaxed">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
