import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Code, Users, Headphones, Cloud, Shield, CheckCircle } from "lucide-react"
import Link from "next/link"

const services = [
  {
    icon: Code,
    title: "Desenvolvimento de Software",
    description: "Soluções sob medida para seu negócio, desde sistemas web até aplicativos móveis.",
    features: ["Desenvolvimento Web", "Aplicativos Móveis", "APIs REST", "Integração de Sistemas"],
    price: "A partir de R$ 5.000",
  },
  {
    icon: Users,
    title: "Consultoria em TI",
    description: "Otimize seus processos tecnológicos e aumente a eficiência da sua empresa.",
    features: ["Auditoria de Sistemas", "Planejamento Estratégico", "Análise de Performance", "Gestão de Projetos"],
    price: "Sob consulta",
  },
  {
    icon: Headphones,
    title: "Suporte Técnico",
    description: "Suporte 24/7 para manter seus sistemas funcionando sem interrupções.",
    features: ["Atendimento 24/7", "SLA Garantido", "Monitoramento Proativo", "Manutenção Preventiva"],
    price: "A partir de R$ 500/mês",
  },
  {
    icon: Cloud,
    title: "Cloud Computing",
    description: "Migração e gestão de infraestrutura em nuvem para maior escalabilidade.",
    features: ["Migração para Cloud", "AWS/Azure/GCP", "DevOps", "Escalabilidade"],
    price: "Sob consulta",
  },
  {
    icon: Shield,
    title: "Segurança da Informação",
    description: "Proteja seus dados e sistemas com soluções completas de segurança.",
    features: ["Firewall e Antivírus", "Gestão de Vulnerabilidades", "Backup e Recuperação", "Compliance"],
    price: "A partir de R$ 3.000/mês",
  },
]

export function ServicesSection() {
  return (
    <section id="servicos" className="bg-white py-20 lg:py-32">
      <div className="container mx-auto px-4">
        <div className="mb-16 text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl lg:text-5xl">
            Nossos Serviços
          </h2>
          <p className="mx-auto max-w-2xl text-pretty text-lg leading-relaxed text-gray-600">
            Oferecemos uma gama completa de serviços tecnológicos para impulsionar o crescimento e a eficiência do seu
            negócio.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => {
            const Icon = service.icon
            return (
              <Card key={service.title} className="relative overflow-hidden transition-all hover:shadow-lg">
                <CardHeader>
                  <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100 text-blue-600">
                    <Icon className="h-6 w-6" />
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                  <CardDescription className="text-base">{service.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="mb-6 space-y-2">
                    {service.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-2 text-sm text-gray-600">
                        <CheckCircle className="h-5 w-5 shrink-0 text-green-500" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="mb-4 text-lg font-semibold text-blue-600">{service.price}</div>
                  <Button variant="outline" className="w-full bg-transparent" asChild>
                    <Link href="#contato">Solicitar Orçamento</Link>
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
