import { Card, CardContent } from "@/components/ui/card"
import { Target, Lightbulb, Users, Award } from "lucide-react"

const values = [
  {
    icon: Target,
    title: "Missão",
    description:
      "Transformar negócios através da tecnologia, oferecendo soluções inovadoras e personalizadas que geram resultados reais.",
  },
  {
    icon: Lightbulb,
    title: "Visão",
    description:
      "Ser referência em soluções tecnológicas, reconhecida pela excelência, inovação e compromisso com o sucesso dos nossos clientes.",
  },
  {
    icon: Users,
    title: "Valores",
    description: "Comprometimento, transparência, inovação e parceria de longo prazo com nossos clientes.",
  },
  {
    icon: Award,
    title: "Qualidade",
    description: "Excelência em cada projeto, utilizando as melhores práticas e tecnologias mais modernas do mercado.",
  },
]

export function AboutSection() {
  return (
    <section id="sobre" className="bg-gray-50 py-20 lg:py-32">
      <div className="container mx-auto px-4">
        <div className="mb-16 text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl lg:text-5xl">
            Sobre a UAI Sistemas
          </h2>
          <p className="mx-auto max-w-3xl text-pretty text-lg leading-relaxed text-gray-600">
            Somos uma empresa especializada em desenvolvimento de software e soluções tecnológicas, com mais de 10 anos
            de experiência no mercado. Nossa equipe de profissionais altamente qualificados está pronta para transformar
            os desafios da sua empresa em oportunidades de crescimento.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {values.map((value) => {
            const Icon = value.icon
            return (
              <Card key={value.title} className="border-none bg-white shadow-sm transition-all hover:shadow-md">
                <CardContent className="flex flex-col items-center p-6 text-center">
                  <div className="mb-4 inline-flex h-16 w-16 items-center justify-center rounded-full bg-blue-100 text-blue-600">
                    <Icon className="h-8 w-8" />
                  </div>
                  <h3 className="mb-2 text-xl font-semibold text-gray-900">{value.title}</h3>
                  <p className="text-sm leading-relaxed text-gray-600">{value.description}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <div className="mt-16 rounded-2xl bg-gradient-to-r from-blue-600 to-cyan-500 p-8 text-center text-white lg:p-12">
          <h3 className="mb-4 text-2xl font-bold sm:text-3xl">Por que escolher a UAI Sistemas?</h3>
          <div className="mx-auto grid max-w-4xl gap-6 md:grid-cols-3">
            <div className="flex flex-col items-center">
              <div className="mb-2 text-4xl font-bold">150+</div>
              <div className="text-sm text-blue-100">Projetos concluídos com sucesso</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="mb-2 text-4xl font-bold">98%</div>
              <div className="text-sm text-blue-100">Taxa de satisfação dos clientes</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="mb-2 text-4xl font-bold">10+</div>
              <div className="text-sm text-blue-100">Anos de experiência no mercado</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
