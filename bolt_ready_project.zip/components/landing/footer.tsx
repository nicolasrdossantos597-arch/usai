import Link from "next/link"
import { Facebook, Instagram, Linkedin, Twitter } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t border-gray-200 bg-gray-50">
      <div className="container mx-auto px-4 py-12">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="mb-4 flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-blue-600 to-cyan-500 text-white font-bold text-lg">
                U
              </div>
              <span className="text-xl font-bold text-gray-900">UAI Sistemas</span>
            </div>
            <p className="mb-4 text-sm leading-relaxed text-gray-600">
              Transformando negócios através da tecnologia com soluções inovadoras e personalizadas.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-gray-400 transition-colors hover:text-blue-600">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 transition-colors hover:text-blue-600">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 transition-colors hover:text-blue-600">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 transition-colors hover:text-blue-600">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-semibold text-gray-900">Serviços</h3>
            <ul className="space-y-3 text-sm text-gray-600">
              <li>
                <Link href="#servicos" className="transition-colors hover:text-blue-600">
                  Desenvolvimento de Software
                </Link>
              </li>
              <li>
                <Link href="#servicos" className="transition-colors hover:text-blue-600">
                  Consultoria em TI
                </Link>
              </li>
              <li>
                <Link href="#servicos" className="transition-colors hover:text-blue-600">
                  Suporte Técnico
                </Link>
              </li>
              <li>
                <Link href="#servicos" className="transition-colors hover:text-blue-600">
                  Cloud Computing
                </Link>
              </li>
              <li>
                <Link href="#servicos" className="transition-colors hover:text-blue-600">
                  Segurança da Informação
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-semibold text-gray-900">Empresa</h3>
            <ul className="space-y-3 text-sm text-gray-600">
              <li>
                <Link href="#sobre" className="transition-colors hover:text-blue-600">
                  Sobre Nós
                </Link>
              </li>
              <li>
                <Link href="#contato" className="transition-colors hover:text-blue-600">
                  Contato
                </Link>
              </li>
              <li>
                <Link href="/login" className="transition-colors hover:text-blue-600">
                  Área do Cliente
                </Link>
              </li>
              <li>
                <Link href="#" className="transition-colors hover:text-blue-600">
                  Trabalhe Conosco
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-semibold text-gray-900">Contato</h3>
            <ul className="space-y-3 text-sm text-gray-600">
              <li>contato@uaisistemas.com.br</li>
              <li>(31) 3333-4444</li>
              <li>WhatsApp: (31) 99999-8888</li>
              <li className="leading-relaxed">
                Av. Afonso Pena, 1500 - Centro
                <br />
                Belo Horizonte, MG
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-gray-200 pt-8 text-center">
          <p className="text-sm text-gray-600">
            © {new Date().getFullYear()} UAI Sistemas. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  )
}
