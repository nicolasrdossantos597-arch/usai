import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Sparkles } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-blue-50 to-white py-20 lg:py-32">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-blue-100 px-4 py-2 text-sm font-medium text-blue-900">
            <Sparkles className="h-4 w-4" />
            Soluções tecnológicas que transformam negócios
          </div>

          <h1 className="mb-6 max-w-4xl text-balance text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl lg:text-6xl">
            Tecnologia e Inovação para o{" "}
            <span className="bg-gradient-to-r from-blue-600 to-cyan-500 bg-clip-text text-transparent">
              Futuro do seu Negócio
            </span>
          </h1>

          <p className="mb-8 max-w-2xl text-pretty text-lg leading-relaxed text-gray-600 sm:text-xl">
            Desenvolvemos soluções personalizadas em software, consultoria em TI e suporte técnico para empresas que
            buscam excelência e resultados reais.
          </p>

          <div className="flex flex-col gap-4 sm:flex-row">
            <Button size="lg" className="gap-2" asChild>
              <Link href="#contato">
                Fale com Especialista
                <ArrowRight className="h-5 w-5" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="#servicos">Conheça nossos serviços</Link>
            </Button>
          </div>

          <div className="mt-16 grid w-full max-w-4xl grid-cols-2 gap-8 lg:grid-cols-4">
            <div className="flex flex-col items-center">
              <div className="mb-2 text-3xl font-bold text-blue-600">150+</div>
              <div className="text-sm text-gray-600">Projetos Entregues</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="mb-2 text-3xl font-bold text-blue-600">98%</div>
              <div className="text-sm text-gray-600">Satisfação dos Clientes</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="mb-2 text-3xl font-bold text-blue-600">24/7</div>
              <div className="text-sm text-gray-600">Suporte Disponível</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="mb-2 text-3xl font-bold text-blue-600">10+</div>
              <div className="text-sm text-gray-600">Anos de Experiência</div>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute -left-4 top-20 h-72 w-72 rounded-full bg-blue-100 opacity-20 blur-3xl" />
      <div className="absolute -right-4 bottom-20 h-72 w-72 rounded-full bg-cyan-100 opacity-20 blur-3xl" />
    </section>
  )
}
