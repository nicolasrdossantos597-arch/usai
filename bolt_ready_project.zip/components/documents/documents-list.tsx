"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { FileText, Upload, Download, Eye, Trash2 } from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

interface File {
  id: string
  file_name: string
  file_url: string
  file_size?: number
  file_type?: string
  description?: string
  created_at: string
  project?: {
    name: string
  }
}

interface DocumentsListProps {
  files: File[]
  userId: string
}

export function DocumentsList({ files: initialFiles, userId }: DocumentsListProps) {
  const [files, setFiles] = useState(initialFiles)

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return "N/A"
    if (bytes < 1024) return bytes + " B"
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB"
    return (bytes / (1024 * 1024)).toFixed(1) + " MB"
  }

  return (
    <div className="space-y-6">
      {/* Upload area */}
      <Card className="border-0 shadow-lg shadow-gray-200/50">
        <CardHeader>
          <CardTitle>Upload de Arquivo</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <Input type="file" className="flex-1" />
            <Button className="gap-2">
              <Upload className="h-4 w-4" />
              Enviar
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Files list */}
      <Card className="border-0 shadow-lg shadow-gray-200/50">
        <CardHeader>
          <CardTitle>Meus Documentos</CardTitle>
        </CardHeader>
        <CardContent>
          {files.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12">
              <FileText className="mb-4 h-16 w-16 text-gray-400" />
              <p className="text-gray-600">Nenhum documento enviado ainda</p>
            </div>
          ) : (
            <div className="space-y-2">
              {files.map((file) => (
                <div
                  key={file.id}
                  className="flex items-center justify-between rounded-lg border border-gray-200 p-4 hover:border-blue-200 hover:bg-blue-50/50"
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className="rounded-lg bg-blue-100 p-2">
                      <FileText className="h-5 w-5 text-blue-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 truncate">{file.file_name}</p>
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <span>{formatFileSize(file.file_size)}</span>
                        <span>•</span>
                        <span>{format(new Date(file.created_at), "dd/MM/yyyy", { locale: ptBR })}</span>
                        {file.project && (
                          <>
                            <span>•</span>
                            <span>{file.project.name}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="icon">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <Trash2 className="h-4 w-4 text-red-600" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
