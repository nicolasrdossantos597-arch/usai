import { ArrowRight, TrendingUp, Users, Clock, DollarSign } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export function CasesList() {
  const cases = [
    {
      company: "LogiTrans Transportes",
      industry: "Logística",
      challenge: "Gestão manual de rotas e frota causando ineficiência operacional",
      solution: "Sistema web de gestão de frotas com otimização de rotas e rastreamento em tempo real",
      results: [
        { icon: TrendingUp, label: "Redução de custos", value: "35%" },
        { icon: Clock, label: "Tempo de entrega", value: "-28%" },
        { icon: Users, label: "Satisfação cliente", value: "+45%" },
      ],
      image: "/logistics-trucks-warehouse.jpg",
      color: "from-blue-500 to-cyan-500",
    },
    {
      company: "MedCare Clínicas",
      industry: "Saúde",
      challenge: "Agendamentos por telefone e prontuários em papel gerando atrasos",
      solution: "Plataforma completa de agendamento online e prontuário eletrônico com integração WhatsApp",
      results: [
        { icon: Users, label: "Agendamentos online", value: "+180%" },
        { icon: Clock, label: "Tempo de atendimento", value: "-40%" },
        { icon: TrendingUp, label: "Receita mensal", value: "+52%" },
      ],
      image: "/medical-clinic-technology.jpg",
      color: "from-cyan-500 to-blue-500",
    },
    {
      company: "StyleShop Fashion",
      industry: "E-commerce",
      challenge: "Loja física limitada e vendas estagnadas",
      solution: "E-commerce completo com app mobile, integração ERP e marketing automation",
      results: [
        { icon: DollarSign, label: "Faturamento anual", value: "+320%" },
        { icon: Users, label: "Novos clientes", value: "+450%" },
        { icon: TrendingUp, label: "Ticket médio", value: "+65%" },
      ],
      image: "/fashion-ecommerce-shopping.jpg",
      color: "from-purple-500 to-pink-500",
    },
    {
      company: "AgriTech Plantações",
      industry: "Agronegócio",
      challenge: "Controle manual de safras e falta de dados para decisões",
      solution: "Sistema IoT de monitoramento de plantações com BI e análise preditiva",
      results: [
        { icon: TrendingUp, label: "Produtividade", value: "+48%" },
        { icon: DollarSign, label: "Redução perdas", value: "42%" },
        { icon: Clock, label: "Tempo de análise", value: "-85%" },
      ],
      image: "/agriculture-technology-iot.jpg",
      color: "from-green-500 to-emerald-500",
    },
    {
      company: "EduConnect Escolas",
      industry: "Educação",
      challenge: "Comunicação fragmentada entre escola, pais e alunos",
      solution: "Plataforma educacional com portal do aluno, app para pais e gestão acadêmica",
      results: [
        { icon: Users, label: "Engajamento pais", value: "+95%" },
        { icon: TrendingUp, label: "Performance alunos", value: "+38%" },
        { icon: Clock, label: "Tarefas admin", value: "-60%" },
      ],
      image: "/education-technology-school.jpg",
      color: "from-indigo-500 to-purple-500",
    },
    {
      company: "FoodHub Delivery",
      industry: "Alimentação",
      challenge: "Dependência de apps terceiros com altas comissões",
      solution: "App próprio de delivery com sistema de gestão e programa de fidelidade",
      results: [
        { icon: DollarSign, label: "Margem de lucro", value: "+85%" },
        { icon: Users, label: "Clientes recorrentes", value: "+140%" },
        { icon: TrendingUp, label: "Pedidos mensais", value: "+210%" },
      ],
      image: "/food-delivery-app-screen.png",
      color: "from-orange-500 to-red-500",
    },
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-7xl mx-auto space-y-16">
          {cases.map((caseStudy, index) => (
            <div
              key={index}
              className={`flex flex-col ${
                index % 2 === 0 ? "lg:flex-row" : "lg:flex-row-reverse"
              } gap-8 items-center bg-gradient-to-br from-gray-50 to-white rounded-3xl p-8 lg:p-12 hover:shadow-2xl transition-all`}
            >
              {/* Image */}
              <div className="flex-1 w-full">
                <div className="aspect-video rounded-2xl overflow-hidden shadow-lg">
                  <img
                    src={caseStudy.image || "/placeholder.svg"}
                    alt={caseStudy.company}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 w-full">
                <div className="inline-block px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium mb-4">
                  {caseStudy.industry}
                </div>
                <h3 className="text-3xl font-bold text-gray-900 mb-4">{caseStudy.company}</h3>

                <div className="space-y-4 mb-6">
                  <div>
                    <h4 className="text-sm font-bold text-gray-500 uppercase mb-2">Desafio</h4>
                    <p className="text-gray-700">{caseStudy.challenge}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-gray-500 uppercase mb-2">Solução</h4>
                    <p className="text-gray-700">{caseStudy.solution}</p>
                  </div>
                </div>

                {/* Results */}
                <div className="grid grid-cols-3 gap-4 mb-6">
                  {caseStudy.results.map((result, idx) => (
                    <div key={idx} className="text-center">
                      <div
                        className={`w-12 h-12 bg-gradient-to-br ${caseStudy.color} rounded-xl flex items-center justify-center mx-auto mb-2`}
                      >
                        <result.icon className="text-white" size={20} />
                      </div>
                      <div className="text-2xl font-bold text-gray-900 mb-1">{result.value}</div>
                      <div className="text-xs text-gray-600">{result.label}</div>
                    </div>
                  ))}
                </div>

                <Link href="/contato">
                  <Button className={`bg-gradient-to-r ${caseStudy.color} hover:shadow-lg transition-all`}>
                    Quero Resultados Assim
                    <ArrowRight className="ml-2" size={16} />
                  </Button>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
