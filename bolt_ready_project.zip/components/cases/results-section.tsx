import { TrendingUp, Users, Clock, Award } from "lucide-react"

export function ResultsSection() {
  const overallResults = [
    {
      icon: TrendingUp,
      value: "320%",
      label: "Crescimento médio em faturamento",
      color: "from-blue-500 to-cyan-500",
    },
    {
      icon: Users,
      value: "180%",
      label: "Aumento em satisfação de clientes",
      color: "from-cyan-500 to-blue-500",
    },
    {
      icon: Clock,
      value: "60%",
      label: "Redução no tempo de processos",
      color: "from-purple-500 to-pink-500",
    },
    {
      icon: Award,
      value: "98%",
      label: "Taxa de sucesso dos projetos",
      color: "from-pink-500 to-purple-500",
    },
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-blue-50 via-white to-cyan-50">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Resultados Comprovados</h2>
          <p className="text-xl text-gray-600">
            Números que refletem o impacto real das nossas soluções em empresas de diversos setores
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
          {overallResults.map((result, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 text-center hover:shadow-xl transition-shadow">
              <div
                className={`w-16 h-16 bg-gradient-to-br ${result.color} rounded-2xl flex items-center justify-center mx-auto mb-4`}
              >
                <result.icon className="text-white" size={32} />
              </div>
              <div className="text-4xl font-bold text-gray-900 mb-2">{result.value}</div>
              <div className="text-gray-600">{result.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
