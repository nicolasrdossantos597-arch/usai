"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { Mail, Phone, Building, CheckCircle } from "lucide-react"
import type { ContactSubmission } from "@/lib/types"

interface ContactsListProps {
  contacts: ContactSubmission[]
}

export function ContactsList({ contacts }: ContactsListProps) {
  const [processingIds, setProcessingIds] = useState<Set<string>>(new Set())
  const { toast } = useToast()
  const router = useRouter()

  const handleMarkAsProcessed = async (id: string) => {
    setProcessingIds((prev) => new Set(prev).add(id))

    try {
      const response = await fetch(`/api/admin/contacts/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ is_processed: true }),
      })

      if (!response.ok) throw new Error("Erro ao processar contato")

      toast({
        title: "Contato processado!",
        description: "O contato foi marcado como processado.",
      })

      router.refresh()
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível processar o contato. Tente novamente.",
        variant: "destructive",
      })
    } finally {
      setProcessingIds((prev) => {
        const newSet = new Set(prev)
        newSet.delete(id)
        return newSet
      })
    }
  }

  if (contacts.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-16 text-center">
          <Mail className="mb-4 h-12 w-12 text-gray-400" />
          <h3 className="mb-2 text-lg font-semibold text-gray-900">Nenhuma mensagem encontrada</h3>
          <p className="text-sm text-gray-600">Ainda não há mensagens de contato no sistema.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="grid gap-4">
      {contacts.map((contact) => (
        <Card key={contact.id}>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="mb-3 flex items-center gap-3">
                  <h3 className="text-lg font-semibold text-gray-900">{contact.name}</h3>
                  {!contact.is_processed ? (
                    <Badge>Novo</Badge>
                  ) : (
                    <Badge variant="outline" className="border-green-500 text-green-700">
                      <CheckCircle className="mr-1 h-3 w-3" />
                      Processado
                    </Badge>
                  )}
                </div>

                <div className="mb-3 flex flex-wrap items-center gap-4 text-sm text-gray-600">
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    {contact.email}
                  </div>
                  {contact.phone && (
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4" />
                      {contact.phone}
                    </div>
                  )}
                  {contact.company && (
                    <div className="flex items-center gap-2">
                      <Building className="h-4 w-4" />
                      {contact.company}
                    </div>
                  )}
                </div>

                <div className="mb-3 rounded-lg bg-gray-50 p-4">
                  <p className="mb-2 font-semibold text-gray-900">Assunto: {contact.subject}</p>
                  <p className="text-sm leading-relaxed text-gray-700">{contact.message}</p>
                </div>

                <div className="flex items-center justify-between">
                  <p className="text-xs text-gray-500">
                    Recebido em {new Date(contact.created_at).toLocaleString("pt-BR")}
                  </p>
                  {!contact.is_processed && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleMarkAsProcessed(contact.id)}
                      disabled={processingIds.has(contact.id)}
                    >
                      Marcar como Processado
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
