"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { createClient } from "@/lib/supabase/client"
import { Save, Eye, EyeOff } from "lucide-react"

interface DashboardContent {
  id: string
  section: string
  title: string | null
  description: string | null
  is_visible: boolean
  display_order: number
}

interface DashboardContentEditorProps {
  initialContent: DashboardContent[]
}

export function DashboardContentEditor({ initialContent }: DashboardContentEditorProps) {
  const [content, setContent] = useState(initialContent)
  const [saving, setSaving] = useState(false)
  const [saveMessage, setSaveMessage] = useState("")
  const supabase = createClient()

  const sectionNames: Record<string, string> = {
    welcome: "Mensagem de Boas-Vindas",
    quick_actions: "Ações Rápidas",
    stats: "Estatísticas",
    projects: "Projetos",
    activity: "Atividade Recente",
  }

  async function handleSave() {
    setSaving(true)
    setSaveMessage("")

    try {
      for (const section of content) {
        const { error } = await supabase
          .from("dashboard_content")
          .update({
            title: section.title,
            description: section.description,
            is_visible: section.is_visible,
          })
          .eq("id", section.id)

        if (error) throw error
      }

      setSaveMessage("Configurações salvas com sucesso!")
      setTimeout(() => setSaveMessage(""), 3000)
    } catch (error) {
      console.error("[v0] Error saving dashboard config:", error)
      setSaveMessage("Erro ao salvar configurações")
    } finally {
      setSaving(false)
    }
  }

  function updateSection(id: string, field: keyof DashboardContent, value: any) {
    setContent((prev) => prev.map((section) => (section.id === id ? { ...section, [field]: value } : section)))
  }

  return (
    <div className="space-y-6">
      {content.map((section) => (
        <Card key={section.id}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>{sectionNames[section.section] || section.section}</CardTitle>
                <CardDescription>Configurar seção "{section.section}"</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                {section.is_visible ? (
                  <Eye className="h-5 w-5 text-green-600" />
                ) : (
                  <EyeOff className="h-5 w-5 text-gray-400" />
                )}
                <Switch
                  checked={section.is_visible}
                  onCheckedChange={(checked) => updateSection(section.id, "is_visible", checked)}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor={`title-${section.id}`}>Título</Label>
              <Input
                id={`title-${section.id}`}
                value={section.title || ""}
                onChange={(e) => updateSection(section.id, "title", e.target.value)}
                placeholder="Título da seção"
              />
            </div>

            {section.section === "welcome" && (
              <div>
                <Label htmlFor={`description-${section.id}`}>Descrição</Label>
                <Textarea
                  id={`description-${section.id}`}
                  value={section.description || ""}
                  onChange={(e) => updateSection(section.id, "description", e.target.value)}
                  placeholder="Mensagem de boas-vindas para os clientes"
                  rows={3}
                />
              </div>
            )}

            {section.section === "projects" && (
              <div>
                <Label htmlFor={`description-${section.id}`}>Descrição</Label>
                <Input
                  id={`description-${section.id}`}
                  value={section.description || ""}
                  onChange={(e) => updateSection(section.id, "description", e.target.value)}
                  placeholder="Subtítulo da seção de projetos"
                />
              </div>
            )}
          </CardContent>
        </Card>
      ))}

      <div className="flex items-center justify-between rounded-lg border border-gray-200 bg-white p-4">
        {saveMessage && (
          <p className={`text-sm font-medium ${saveMessage.includes("sucesso") ? "text-green-600" : "text-red-600"}`}>
            {saveMessage}
          </p>
        )}
        <div className="ml-auto">
          <Button onClick={handleSave} disabled={saving}>
            <Save className="mr-2 h-4 w-4" />
            {saving ? "Salvando..." : "Salvar Alterações"}
          </Button>
        </div>
      </div>
    </div>
  )
}
