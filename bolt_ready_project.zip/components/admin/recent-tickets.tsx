import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowRight } from "lucide-react"
import type { Ticket } from "@/lib/types"

interface RecentTicketsAdminProps {
  tickets: Ticket[]
}

const statusMap = {
  open: { label: "Aberto", variant: "default" as const },
  in_progress: { label: "Em Andamento", variant: "secondary" as const },
  resolved: { label: "Resolvido", variant: "outline" as const },
  closed: { label: "Fechado", variant: "outline" as const },
}

export function RecentTicketsAdmin({ tickets }: RecentTicketsAdminProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Tickets Recentes</CardTitle>
        <CardDescription>Últimos chamados de suporte criados</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {tickets.map((ticket) => (
            <Link
              key={ticket.id}
              href={`/admin/tickets/${ticket.id}`}
              className="block rounded-lg border border-gray-200 p-4 transition-colors hover:bg-gray-50"
            >
              <div className="mb-2 flex items-start justify-between">
                <h3 className="font-semibold text-gray-900">{ticket.title}</h3>
                <Badge variant={statusMap[ticket.status].variant}>{statusMap[ticket.status].label}</Badge>
              </div>
              <p className="mb-2 text-sm text-gray-600">Cliente: {ticket.user?.full_name}</p>
              <div className="text-xs text-gray-500">{new Date(ticket.created_at).toLocaleDateString("pt-BR")}</div>
            </Link>
          ))}
          <Button variant="outline" className="w-full bg-transparent" asChild>
            <Link href="/admin/tickets">
              Ver Todos os Tickets
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
