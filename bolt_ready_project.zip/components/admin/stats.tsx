import { Card, CardContent } from "@/components/ui/card"
import { Users, Ticket, CheckCircle, Mail } from "lucide-react"

interface AdminStatsProps {
  totalClients: number
  openTickets: number
  totalTickets: number
  pendingContacts: number
}

export function AdminStats({ totalClients, openTickets, totalTickets, pendingContacts }: AdminStatsProps) {
  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardContent className="flex items-center gap-4 p-6">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100">
            <Users className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-600">Total de Clientes</p>
            <p className="text-2xl font-bold text-gray-900">{totalClients}</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex items-center gap-4 p-6">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-orange-100">
            <Ticket className="h-6 w-6 text-orange-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-600">Tickets Abertos</p>
            <p className="text-2xl font-bold text-gray-900">{openTickets}</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex items-center gap-4 p-6">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-green-100">
            <CheckCircle className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-600">Total de Tickets</p>
            <p className="text-2xl font-bold text-gray-900">{totalTickets}</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex items-center gap-4 p-6">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-purple-100">
            <Mail className="h-6 w-6 text-purple-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-600">Contatos Pendentes</p>
            <p className="text-2xl font-bold text-gray-900">{pendingContacts}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
