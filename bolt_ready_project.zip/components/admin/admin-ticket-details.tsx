"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { Loader2 } from "lucide-react"
import type { Ticket, TicketStatus } from "@/lib/types"

interface AdminTicketDetailsProps {
  ticket: Ticket
}

const statusMap = {
  open: { label: "Aberto", variant: "default" as const },
  in_progress: { label: "Em Andamento", variant: "secondary" as const },
  resolved: { label: "Resolvido", variant: "outline" as const },
  closed: { label: "Fechado", variant: "outline" as const },
}

const priorityMap = {
  low: { label: "Baixa", color: "bg-gray-100 text-gray-700" },
  medium: { label: "Média", color: "bg-blue-100 text-blue-700" },
  high: { label: "Alta", color: "bg-orange-100 text-orange-700" },
  urgent: { label: "Urgente", color: "bg-red-100 text-red-700" },
}

export function AdminTicketDetails({ ticket }: AdminTicketDetailsProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [status, setStatus] = useState<TicketStatus>(ticket.status)
  const { toast } = useToast()
  const router = useRouter()

  const handleStatusUpdate = async () => {
    setIsLoading(true)

    try {
      const response = await fetch(`/api/admin/tickets/${ticket.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      })

      if (!response.ok) throw new Error("Erro ao atualizar ticket")

      toast({
        title: "Ticket atualizado!",
        description: "O status do ticket foi alterado com sucesso.",
      })

      router.refresh()
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o ticket. Tente novamente.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Detalhes do Ticket</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <p className="mb-1 text-sm font-medium text-gray-600">Cliente</p>
          <p className="text-sm text-gray-900">{ticket.user?.full_name}</p>
          <p className="text-xs text-gray-500">{ticket.user?.email}</p>
        </div>

        <div>
          <p className="mb-1 text-sm font-medium text-gray-600">Título</p>
          <p className="text-sm text-gray-900">{ticket.title}</p>
        </div>

        <div>
          <p className="mb-2 text-sm font-medium text-gray-600">Status</p>
          <Select value={status} onValueChange={(value) => setStatus(value as TicketStatus)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="open">Aberto</SelectItem>
              <SelectItem value="in_progress">Em Andamento</SelectItem>
              <SelectItem value="resolved">Resolvido</SelectItem>
              <SelectItem value="closed">Fechado</SelectItem>
            </SelectContent>
          </Select>
          {status !== ticket.status && (
            <Button className="mt-2 w-full" onClick={handleStatusUpdate} disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Salvando...
                </>
              ) : (
                "Salvar Status"
              )}
            </Button>
          )}
        </div>

        <div>
          <p className="mb-1 text-sm font-medium text-gray-600">Prioridade</p>
          <Badge className={priorityMap[ticket.priority].color}>{priorityMap[ticket.priority].label}</Badge>
        </div>

        <div>
          <p className="mb-1 text-sm font-medium text-gray-600">Descrição</p>
          <p className="text-sm leading-relaxed text-gray-900">{ticket.description}</p>
        </div>

        <div>
          <p className="mb-1 text-sm font-medium text-gray-600">Criado em</p>
          <p className="text-sm text-gray-900">{new Date(ticket.created_at).toLocaleString("pt-BR")}</p>
        </div>
      </CardContent>
    </Card>
  )
}
