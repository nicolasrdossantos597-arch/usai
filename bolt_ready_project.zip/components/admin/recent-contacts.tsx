import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowRight } from "lucide-react"
import type { ContactSubmission } from "@/lib/types"

interface RecentContactsAdminProps {
  contacts: ContactSubmission[]
}

export function RecentContactsAdmin({ contacts }: RecentContactsAdminProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Contatos Recentes</CardTitle>
        <CardDescription>Últimas mensagens do formulário de contato</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {contacts.map((contact) => (
            <div key={contact.id} className="rounded-lg border border-gray-200 p-4">
              <div className="mb-2 flex items-start justify-between">
                <h3 className="font-semibold text-gray-900">{contact.name}</h3>
                {!contact.is_processed && <Badge>Novo</Badge>}
              </div>
              <p className="mb-1 text-sm text-gray-600">{contact.email}</p>
              <p className="mb-2 text-sm font-medium text-gray-700">{contact.subject}</p>
              <p className="mb-2 line-clamp-2 text-sm text-gray-600">{contact.message}</p>
              <div className="text-xs text-gray-500">{new Date(contact.created_at).toLocaleDateString("pt-BR")}</div>
            </div>
          ))}
          <Button variant="outline" className="w-full bg-transparent" asChild>
            <Link href="/admin/contatos">
              Ver Todos os Contatos
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
