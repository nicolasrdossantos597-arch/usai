import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Ticket } from "@/lib/types"

interface AdminTicketsListProps {
  tickets: Ticket[]
}

const statusMap = {
  open: { label: "Aberto", variant: "default" as const },
  in_progress: { label: "Em Andamento", variant: "secondary" as const },
  resolved: { label: "Resolvido", variant: "outline" as const },
  closed: { label: "Fechado", variant: "outline" as const },
}

const priorityMap = {
  low: { label: "Baixa", color: "text-gray-600" },
  medium: { label: "Média", color: "text-blue-600" },
  high: { label: "Alta", color: "text-orange-600" },
  urgent: { label: "Urgente", color: "text-red-600" },
}

export function AdminTicketsList({ tickets }: AdminTicketsListProps) {
  if (tickets.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-16 text-center">
          <h3 className="mb-2 text-lg font-semibold text-gray-900">Nenhum ticket encontrado</h3>
          <p className="text-sm text-gray-600">Ainda não há tickets de suporte no sistema.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="grid gap-4">
      {tickets.map((ticket) => (
        <Link key={ticket.id} href={`/admin/tickets/${ticket.id}`}>
          <Card className="transition-all hover:shadow-md">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="mb-2 flex items-center gap-3">
                    <h3 className="text-lg font-semibold text-gray-900">{ticket.title}</h3>
                    <Badge variant={statusMap[ticket.status].variant}>{statusMap[ticket.status].label}</Badge>
                  </div>
                  <p className="mb-3 line-clamp-2 text-sm leading-relaxed text-gray-600">{ticket.description}</p>
                  <div className="flex flex-wrap items-center gap-4 text-xs text-gray-500">
                    <span>Cliente: {ticket.user?.full_name}</span>
                    <span>•</span>
                    <span className={priorityMap[ticket.priority].color}>
                      Prioridade: {priorityMap[ticket.priority].label}
                    </span>
                    <span>•</span>
                    <span>Criado em {new Date(ticket.created_at).toLocaleDateString("pt-BR")}</span>
                    {ticket.assigned_user && (
                      <>
                        <span>•</span>
                        <span>Atribuído: {ticket.assigned_user.full_name}</span>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}
