"use client"

import { Search, MessageSquare } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useState } from "react"
import type { Profile } from "@/lib/types"

interface Conversation {
  id: string
  client_profile?: Profile
  admin_profile?: Profile
  last_message?: {
    content: string
    created_at: string
  }
  unread_count?: number
}

interface ConversationsSidebarProps {
  profile: Profile
  conversations: Conversation[]
  selectedConversation: Conversation | null
  onSelectConversation: (conversation: Conversation) => void
  isAdmin: boolean
}

export function ConversationsSidebar({
  profile,
  conversations,
  selectedConversation,
  onSelectConversation,
  isAdmin,
}: ConversationsSidebarProps) {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredConversations = conversations.filter((conv) => {
    if (!searchQuery) return true

    const targetProfile = isAdmin ? conv.client_profile : conv.admin_profile
    return targetProfile?.full_name?.toLowerCase().includes(searchQuery.toLowerCase())
  })

  function formatTime(timestamp: string | null) {
    if (!timestamp) return ""

    const date = new Date(timestamp)
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const hours = diff / (1000 * 60 * 60)

    if (hours < 24) {
      return date.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })
    } else if (hours < 48) {
      return "Ontem"
    } else {
      return date.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })
    }
  }

  return (
    <div className="flex w-full flex-col border-r border-gray-200 bg-white md:w-[400px]">
      {/* Header */}
      <div className="border-b border-gray-200 bg-[#f0f2f5] px-4 py-6">
        <h1 className="text-2xl font-semibold text-gray-900">Mensagens</h1>
        <p className="mt-1 text-sm text-gray-600">{isAdmin ? "Conversas com clientes" : "Suporte Usai Sistemas"}</p>
      </div>

      {/* Search */}
      <div className="border-b border-gray-200 bg-white px-3 py-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <Input
            type="text"
            placeholder="Buscar conversas..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Conversations List */}
      <div className="flex-1 overflow-y-auto">
        {filteredConversations.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <MessageSquare className="mb-4 h-12 w-12 text-gray-400" />
            <p className="text-sm font-medium text-gray-900">Nenhuma conversa</p>
            <p className="mt-1 text-sm text-gray-500">
              {isAdmin ? "Aguardando mensagens de clientes" : "Inicie uma conversa com o suporte"}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {filteredConversations.map((conversation) => {
              const displayProfile = isAdmin ? conversation.client_profile : conversation.admin_profile
              const isSelected = selectedConversation?.id === conversation.id
              const hasUnread = (conversation.unread_count || 0) > 0

              return (
                <button
                  key={conversation.id}
                  onClick={() => onSelectConversation(conversation)}
                  className={`flex w-full items-start gap-3 px-4 py-4 text-left transition-colors hover:bg-gray-50 ${
                    isSelected ? "bg-gray-100" : ""
                  }`}
                >
                  <Avatar className="h-12 w-12 flex-shrink-0">
                    <AvatarImage src={displayProfile?.avatar_url || ""} />
                    <AvatarFallback className="bg-blue-500 text-white">
                      {displayProfile?.full_name?.charAt(0) || "?"}
                    </AvatarFallback>
                  </Avatar>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className={`truncate text-sm ${hasUnread ? "font-semibold" : "font-medium"} text-gray-900`}>
                        {displayProfile?.full_name || "Usuário"}
                      </h3>
                      <span className="flex-shrink-0 text-xs text-gray-500">
                        {formatTime(conversation.last_message?.created_at || conversation.last_message_at)}
                      </span>
                    </div>

                    <div className="mt-1 flex items-center justify-between gap-2">
                      <p className={`truncate text-sm ${hasUnread ? "font-medium text-gray-900" : "text-gray-600"}`}>
                        {conversation.last_message?.content || "Sem mensagens"}
                      </p>
                      {hasUnread && (
                        <span className="flex-shrink-0 rounded-full bg-green-500 px-2 py-0.5 text-xs font-medium text-white">
                          {conversation.unread_count}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
