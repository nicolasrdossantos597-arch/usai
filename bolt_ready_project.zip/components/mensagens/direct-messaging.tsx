"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { ConversationsSidebar } from "./conversations-sidebar"
import { MessageWindow } from "./message-window"
import type { Profile } from "@/lib/types"

export async function fetchConversationsForUser(profileId: string, isAdmin = false) {
  const supabase = createClient();
  if (isAdmin) {
    const { data, error } = await supabase
      .from("conversations")
      .select(`
        id,
        client_id,
        admin_id,
        last_message_at,
        client_profile:profiles(id, full_name, avatar_url, role),
        admin_profile:profiles(id, full_name, avatar_url, role)
      `)
      .order("last_message_at", { ascending: false });

    if (error) throw error;
    return data;
  } else {
    const { data, error } = await supabase
      .from("conversations")
      .select(`
        id,
        client_id,
        admin_id,
        last_message_at,
        client_profile:profiles(id, full_name, avatar_url, role),
        admin_profile:profiles(id, full_name, avatar_url, role)
      `)
      .eq("client_id", profileId)
      .order("last_message_at", { ascending: false });

    if (error) throw error;
    return data;
  }
}

interface Conversation {
  id: string
  client_id: string
  admin_id: string | null
  last_message_at: string | null
  client_profile?: Profile
  admin_profile?: Profile
  unread_count?: number
  last_message?: {
    content: string
    created_at: string
  }
}

interface DirectMessagingProps {
  profile: Profile
}

export function DirectMessaging({ profile }: DirectMessagingProps) {
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null)
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  const isAdmin = profile.role === "admin"

  useEffect(() => {
    loadConversations()
    const cleanup = subscribeToChanges()

    return () => {
      cleanup()
    }
  }, [])

  async function loadConversations() {
    console.log("[v0] Loading conversations for user:", profile.id, "isAdmin:", isAdmin)

    try {
      let query = supabase.from("conversations").select("*")

      if (isAdmin) {
        query = query.eq("admin_id", profile.id)
      } else {
        query = query.eq("client_id", profile.id)
      }

      const { data: convos, error } = await query.order("last_message_at", { ascending: false, nullsFirst: false })

      if (error) {
        console.error("[v0] Error loading conversations:", error)
        setLoading(false)
        return
      }

      console.log("[v0] Found conversations:", convos?.length || 0)

      if (!convos || convos.length === 0) {
        if (!isAdmin) {
          await createConversationForClient()
        }
        setLoading(false)
        return
      }

      const conversationsWithDetails = await Promise.all(
        convos.map(async (convo) => {
          // Get client profile
          const { data: clientProfile } = await supabase.from("profiles").select("*").eq("id", convo.client_id).single()

          // Get admin profile if exists
          let adminProfile = null
          if (convo.admin_id) {
            const { data: admin } = await supabase.from("profiles").select("*").eq("id", convo.admin_id).single()
            adminProfile = admin
          }

          // Get last message
          const { data: lastMessages } = await supabase
            .from("conversation_messages")
            .select("content, created_at")
            .eq("conversation_id", convo.id)
            .order("created_at", { ascending: false })
            .limit(1)

          // Count unread messages
          const { count: unreadCount } = await supabase
            .from("conversation_messages")
            .select("*", { count: "exact", head: true })
            .eq("conversation_id", convo.id)
            .eq("is_read", false)
            .neq("sender_id", profile.id)

          return {
            ...convo,
            client_profile: clientProfile,
            admin_profile: adminProfile,
            last_message: lastMessages?.[0] || null,
            unread_count: unreadCount || 0,
          }
        }),
      )

      console.log("[v0] Loaded conversations with details:", conversationsWithDetails.length)
      setConversations(conversationsWithDetails)

      if (conversationsWithDetails.length > 0 && !selectedConversation) {
        setSelectedConversation(conversationsWithDetails[0])
      }
    } catch (error) {
      console.error("[v0] Error loading conversations:", error)
    } finally {
      setLoading(false)
    }
  }

  async function createConversationForClient() {
    console.log("[v0] Attempting to create conversation for client:", profile.id)

    try {
      // Get admin user
      const { data: adminProfile } = await supabase.from("profiles").select("*").eq("role", "admin").limit(1).single()

      if (!adminProfile) {
        console.error("[v0] No admin user found")
        return
      }

      console.log("[v0] Found admin:", adminProfile.id)

      // Create conversation
      const { data: newConvo, error } = await supabase
        .from("conversations")
        .insert({
          client_id: profile.id,
          admin_id: adminProfile.id,
        })
        .select()
        .single()

      if (error) {
        console.error("[v0] Error creating conversation:", error)
        return
      }

      console.log("[v0] Created new conversation:", newConvo.id)

      // Reload conversations
      await loadConversations()
    } catch (error) {
      console.error("[v0] Error in createConversationForClient:", error)
    }
  }

  function subscribeToChanges() {
    console.log("[v0] Setting up real-time subscriptions")

    // Subscribe to new messages
    const messagesChannel = supabase
      .channel("messages-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "conversation_messages",
        },
        (payload) => {
          console.log("[v0] Message change detected:", payload.eventType)
          loadConversations()
        },
      )
      .subscribe()

    // Subscribe to conversations changes
    const conversationsChannel = supabase
      .channel("conversations-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "conversations",
        },
        (payload) => {
          console.log("[v0] Conversation change detected:", payload.eventType)
          loadConversations()
        },
      )
      .subscribe()

    return () => {
      console.log("[v0] Cleaning up subscriptions")
      supabase.removeChannel(messagesChannel)
      supabase.removeChannel(conversationsChannel)
    }
  }

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-[#f0f2f5]">
        <div className="text-lg text-gray-600">Carregando conversas...</div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-[#f0f2f5]">
      <ConversationsSidebar
        profile={profile}
        conversations={conversations}
        selectedConversation={selectedConversation}
        onSelectConversation={setSelectedConversation}
        isAdmin={isAdmin}
      />

      <MessageWindow
        profile={profile}
        conversation={selectedConversation}
        onBack={() => setSelectedConversation(null)}
      />
    </div>
  )
}
