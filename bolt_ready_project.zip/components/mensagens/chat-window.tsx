"use client"

import { useEffect, useRef, useState } from "react"
import { Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { createClient } from "@/lib/supabase/client"
import type { Profile } from "@/lib/types"

interface Message {
  id: string
  room_id: string
  sender_id: string
  content: string
  created_at: string
}

interface Room {
  id: string
  name: string
  is_group: boolean
}

interface ChatWindowProps {
  profile: Profile
  selectedRoom: Room | null
}

export default function ChatWindow({ profile, selectedRoom }: ChatWindowProps) {
  const supabase = createClient()
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [loading, setLoading] = useState(false)
  const [sending, setSending] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const isOwn = (sender_id: string) => sender_id === profile.id

  useEffect(() => {
    if (!selectedRoom) return

    const loadMessages = async () => {
      setLoading(true)
      const { data, error } = await supabase
        .from("conversation_messages")
        .select("*")
        .eq("conversation_id", selectedRoom.id)
        .order("created_at", { ascending: true })

      if (error) {
        console.error("Erro ao carregar mensagens:", error)
      } else if (data) {
        setMessages(data)
      }
      setLoading(false)
    }

    loadMessages()

    const channel = supabase
      .channel(`conversation-${selectedRoom.id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "conversation_messages",
          filter: `conversation_id=eq.${selectedRoom.id}`,
        },
        (payload) => {
          const newMsg = payload.new as Message
          setMessages((prev) => [...prev, newMsg])
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [selectedRoom])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  async function handleSendMessage(e: React.FormEvent) {
    e.preventDefault()
    if (!selectedRoom || !newMessage.trim() || sending) return

    setSending(true)
    const { error } = await supabase.from("conversation_messages").insert({
      conversation_id: selectedRoom.id,
      sender_id: profile.id,
      content: newMessage.trim(),
    })

    if (error) {
      console.error("Erro ao enviar mensagem:", error)
      alert("Erro ao enviar mensagem. Tente novamente.")
    } else {
      setNewMessage("")
    }

    setSending(false)
  }

  return (
    <div className="flex flex-col flex-1 bg-[#e5ddd5]">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-200 bg-[#f0f2f5] px-4 py-3">
        <h2 className="font-semibold text-gray-800 truncate">
          {selectedRoom ? selectedRoom.name : "Selecione um chat"}
        </h2>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4">
        {loading ? (
          <div className="flex h-full items-center justify-center text-gray-500">
            Carregando mensagens...
          </div>
        ) : messages.length === 0 ? (
          <div className="flex h-full items-center justify-center text-gray-500">
            Nenhuma mensagem ainda.
          </div>
        ) : (
          <div className="space-y-2">
            {messages.map((message) => {
              const own = isOwn(message.sender_id)
              return (
                <div
                  key={message.id}
                  className={`flex ${own ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[70%] rounded-lg px-3 py-2 shadow-sm ${
                      own ? "bg-[#dcf8c6]" : "bg-white"
                    }`}
                  >
                    <p className="text-sm text-gray-800 whitespace-pre-wrap break-words">
                      {message.content}
                    </p>
                    <p className="text-right text-xs text-gray-500 mt-1">
                      {new Date(message.created_at).toLocaleTimeString("pt-BR", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                </div>
              )
            })}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Input */}
      <form
        onSubmit={handleSendMessage}
        className="border-t border-gray-200 bg-[#f0f2f5] p-4"
      >
        <div className="flex gap-2 items-end">
          <Textarea
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Digite uma mensagem..."
            className="flex-1 min-h-[44px] resize-none"
            disabled={sending}
            rows={1}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault()
                handleSendMessage(e)
              }
            }}
          />
          <Button
            type="submit"
            disabled={!newMessage.trim() || sending}
            size="icon"
            className="h-11 w-11"
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </form>
    </div>
  )
}
