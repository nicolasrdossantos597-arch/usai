"use client"

import type React from "react"
import { useEffect, useState, useRef } from "react"
import { createClient } from "@/lib/supabase/client"
import { Send, ArrowLeft, MoreVertical } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import type { Profile } from "@/lib/types"

interface Message {
  id: string
  conversation_id: string
  sender_id: string
  content: string
  is_read: boolean
  created_at: string
}

interface Conversation {
  id: string
  client_id: string
  admin_id: string | null
  client_profile?: Profile
  admin_profile?: Profile
}

interface MessageWindowProps {
  profile: Profile
  conversation: Conversation | null
  onBack: () => void
}

export function MessageWindow({ profile, conversation, onBack }: MessageWindowProps) {
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [sending, setSending] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const supabase = createClient()

  const isAdmin = profile.role === "admin"

  // 🔹 Carrega mensagens quando a conversa muda
  useEffect(() => {
    if (!conversation) return
    loadMessages()
  }, [conversation])

  // 🔹 Marca mensagens como lidas e faz inscrição em tempo real
  useEffect(() => {
    if (!conversation) return

    const conversationId = conversation.id

    const markAsRead = async () => {
      await supabase
        .from("conversation_messages")
        .update(
          isAdmin ? { read_by_admin: true } : { read_by_client: true }
        )
        .eq("conversation_id", conversationId)
    }

    markAsRead()

    const cleanup = subscribeToMessages()
    return cleanup
  }, [conversation, isAdmin])

  // 🔹 Scroll automático ao final das mensagens
  useEffect(() => {
    scrollToBottom()
  }, [messages])

  async function loadMessages() {
    if (!conversation) return

    const { data, error } = await supabase
      .from("conversation_messages")
      .select("*")
      .eq("conversation_id", conversation.id)
      .order("created_at", { ascending: true })

    if (error) {
      console.error("[v0] Error loading messages:", error)
      return
    }

    if (data) setMessages(data)
  }

  async function markAsRead() {
    if (!conversation) return

    const { error } = await supabase
      .from("conversation_messages")
      .update({ is_read: true, read_at: new Date().toISOString() })
      .eq("conversation_id", conversation.id)
      .eq("is_read", false)
      .neq("sender_id", profile.id)

    if (error) console.error("[v0] Error marking messages as read:", error)
  }

  function subscribeToMessages() {
    if (!conversation) return () => {}

    const channel = supabase
      .channel(`conversation-${conversation.id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "conversation_messages",
          filter: `conversation_id=eq.${conversation.id}`,
        },
        (payload) => {
          const newMsg = payload.new as Message
          setMessages((prev) => [...prev, newMsg])
          if (newMsg.sender_id !== profile.id) {
            markAsRead()
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }

  async function handleSendMessage(e: React.FormEvent) {
    e.preventDefault()
    if (!newMessage.trim() || !conversation || sending) return

    setSending(true)
    try {
      const { error } = await supabase.from("conversation_messages").insert({
        conversation_id: conversation.id,
        sender_id: profile.id,
        content: newMessage.trim(),
      })

      if (error) throw error
      setNewMessage("")
    } catch (error) {
      console.error("[v0] Error sending message:", error)
      alert("Erro ao enviar mensagem. Por favor, tente novamente.")
    } finally {
      setSending(false)
    }
  }

  function scrollToBottom() {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  if (!conversation) {
    return (
      <div className="flex flex-1 items-center justify-center bg-[#f0f2f5]">
        <div className="text-center">
          <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-gray-200">
            <Send className="h-10 w-10 text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900">
            Selecione uma conversa
          </h3>
          <p className="mt-1 text-sm text-gray-600">
            {isAdmin
              ? "Escolha um cliente para começar a conversar"
              : "Envie uma mensagem para o suporte"}
          </p>
        </div>
      </div>
    )
  }

  const otherProfile = isAdmin
    ? conversation.client_profile
    : conversation.admin_profile

  return (
    <div className="flex flex-1 flex-col">
      {/* Header */}
      <div className="flex items-center gap-3 border-b border-gray-200 bg-[#f0f2f5] px-4 py-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={onBack}
          className="md:hidden"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>

        <Avatar className="h-10 w-10">
          <AvatarImage src={otherProfile?.avatar_url || ""} />
          <AvatarFallback className="bg-blue-500 text-white">
            {otherProfile?.full_name?.charAt(0) || "?"}
          </AvatarFallback>
        </Avatar>

        <div className="flex-1">
          <h2 className="font-semibold text-gray-900">
            {otherProfile?.full_name || "Usuário"}
          </h2>
          <p className="text-xs text-gray-600">{otherProfile?.email}</p>
        </div>

        <Button variant="ghost" size="icon">
          <MoreVertical className="h-5 w-5" />
        </Button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto bg-[#e5ddd5] p-4">
        {messages.length === 0 ? (
          <div className="flex h-full items-center justify-center">
            <p className="text-sm text-gray-600">
              Nenhuma mensagem ainda. Comece a conversar!
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {messages.map((message) => {
              const isMine = message.sender_id === profile.id
              return (
                <div
                  key={message.id}
                  className={`flex ${isMine ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[70%] rounded-lg px-3 py-2 ${
                      isMine ? "bg-[#dcf8c6]" : "bg-white"
                    } shadow-sm`}
                  >
                    <p className="whitespace-pre-wrap break-words text-sm text-gray-900">
                      {message.content}
                    </p>
                    <p className="mt-1 text-right text-xs text-gray-500">
                      {new Date(message.created_at).toLocaleTimeString(
                        "pt-BR",
                        {
                          hour: "2-digit",
                          minute: "2-digit",
                        },
                      )}
                    </p>
                  </div>
                </div>
              )
            })}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Input */}
      <form
        onSubmit={handleSendMessage}
        className="border-t border-gray-200 bg-[#f0f2f5] p-4"
      >
        <div className="flex gap-2">
          <Textarea
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault()
                handleSendMessage(e)
              }
            }}
            placeholder="Digite uma mensagem..."
            className="min-h-[44px] flex-1 resize-none"
            rows={1}
            disabled={sending}
          />
          <Button
            type="submit"
            disabled={!newMessage.trim() || sending}
            size="icon"
            className="h-11 w-11"
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </form>
    </div>
  )
}
