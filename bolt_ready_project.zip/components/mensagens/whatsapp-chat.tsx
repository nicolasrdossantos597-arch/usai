"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { ChatSidebar } from "./chat-sidebar"
import { ChatWindow } from "./chat-window"
import { CreateGroupDialog } from "./create-group-dialog"
import type { Profile } from "@/lib/types"

interface ChatRoom {
  id: string
  name: string
  is_group: boolean
  avatar_url: string | null
  last_message_at: string | null
  company_id: string | null
}

interface ChatRoomWithMembers extends ChatRoom {
  members?: Profile[]
  lastMessage?: {
    content: string
    created_at: string
    sender_id: string
  }
  unreadCount?: number
}

interface WhatsAppChatProps {
  profile: Profile
}

export function WhatsAppChat({ profile }: WhatsAppChatProps) {
  const [chatRooms, setChatRooms] = useState<ChatRoomWithMembers[]>([])
  const [selectedRoom, setSelectedRoom] = useState<ChatRoomWithMembers | null>(null)
  const [showCreateGroup, setShowCreateGroup] = useState(false)
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  const isAdmin = profile.role === "admin"

  useEffect(() => {
    loadChatRooms()
    subscribeToChanges()
  }, [])

  async function loadChatRooms() {
    try {
      // Buscar salas do usuário
      const { data: roomMembers } = await supabase
        .from("chat_room_members")
        .select(`
          chat_room_id,
          chat_rooms (
            id,
            name,
            is_group,
            avatar_url,
            last_message_at,
            company_id
          )
        `)
        .eq("user_id", profile.id)

      if (!roomMembers) {
        setLoading(false)
        return
      }

      // Processar cada sala
      const roomsWithDetails = await Promise.all(
        roomMembers.map(async (rm: any) => {
          const room = rm.chat_rooms

          // Buscar membros da sala
          const { data: members } = await supabase
            .from("chat_room_members")
            .select("user_id, profiles(*)")
            .eq("chat_room_id", room.id)

          // Buscar última mensagem
          const { data: lastMessages } = await supabase
            .from("direct_messages")
            .select("content, created_at, sender_id")
            .eq("chat_room_id", room.id)
            .order("created_at", { ascending: false })
            .limit(1)

          // Contar mensagens não lidas
          const { count: unreadCount } = await supabase
            .from("direct_messages")
            .select("*", { count: "exact", head: true })
            .eq("chat_room_id", room.id)
            .eq("is_read", false)
            .neq("sender_id", profile.id)

          // Para salas diretas, usar nome do outro usuário
          let roomName = room.name
          if (!room.is_group && members) {
            const otherMember = members.find((m: any) => m.user_id !== profile.id)
            if (otherMember?.profiles) {
              roomName = otherMember.profiles.full_name
            }
          }

          return {
            ...room,
            name: roomName,
            members: members?.map((m: any) => m.profiles).filter(Boolean) || [],
            lastMessage: lastMessages?.[0] || null,
            unreadCount: unreadCount || 0,
          }
        }),
      )

      // Ordenar por última mensagem
      roomsWithDetails.sort((a, b) => {
        const aTime = a.last_message_at || a.lastMessage?.created_at || "0"
        const bTime = b.last_message_at || b.lastMessage?.created_at || "0"
        return new Date(bTime).getTime() - new Date(aTime).getTime()
      })

      setChatRooms(roomsWithDetails)
    } catch (error) {
      console.error("[v0] Error loading chat rooms:", error)
    } finally {
      setLoading(false)
    }
  }

  function subscribeToChanges() {
    // Subscribe to new messages
    const messagesChannel = supabase
      .channel("messages-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "direct_messages",
        },
        () => {
          loadChatRooms()
        },
      )
      .subscribe()

    // Subscribe to chat rooms changes
    const roomsChannel = supabase
      .channel("rooms-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "chat_rooms",
        },
        () => {
          loadChatRooms()
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(messagesChannel)
      supabase.removeChannel(roomsChannel)
    }
  }

  async function handleCreateGroup(name: string, memberIds: string[]) {
    try {
      // Criar sala de grupo
      const { data: newRoom, error: roomError } = await supabase
        .from("chat_rooms")
        .insert({
          name,
          is_group: true,
          created_by: profile.id,
          company_id: profile.company_id,
        })
        .select()
        .single()

      if (roomError) throw roomError

      // Adicionar membros (incluindo o criador)
      const allMemberIds = [...new Set([profile.id, ...memberIds])]
      const { error: membersError } = await supabase
        .from("chat_room_members")
        .insert(allMemberIds.map((userId) => ({ chat_room_id: newRoom.id, user_id: userId })))

      if (membersError) throw membersError

      await loadChatRooms()
      setShowCreateGroup(false)
    } catch (error) {
      console.error("[v0] Error creating group:", error)
    }
  }

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-[#f0f2f5]">
        <div className="text-lg text-gray-600">Carregando mensagens...</div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-[#f0f2f5]">
      <ChatSidebar
        profile={profile}
        chatRooms={chatRooms}
        selectedRoom={selectedRoom}
        onSelectRoom={setSelectedRoom}
        onCreateGroup={() => setShowCreateGroup(true)}
        isAdmin={isAdmin}
      />

      <ChatWindow profile={profile} selectedRoom={selectedRoom} onBack={() => setSelectedRoom(null)} />

      {showCreateGroup && (
        <CreateGroupDialog
          profile={profile}
          onClose={() => setShowCreateGroup(false)}
          onCreateGroup={handleCreateGroup}
        />
      )}
    </div>
  )
}
