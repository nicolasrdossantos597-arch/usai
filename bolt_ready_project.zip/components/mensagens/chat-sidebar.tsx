"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { Profile } from "@/lib/types"

interface Conversation {
  id: string
  client_id: string
  admin_id: string | null
  client_profile?: Profile
  admin_profile?: Profile
}

interface ChatSidebarProps {
  profile: Profile
  onSelectConversation: (conversation: Conversation) => void
  selectedConversationId: string | null
}

export default function ChatSidebar({
  profile,
  onSelectConversation,
  selectedConversationId,
}: ChatSidebarProps) {
  const supabase = createClient()
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [search, setSearch] = useState("")

  const isAdmin = profile.role === "admin"

  useEffect(() => {
    const fetchConversations = async () => {
      const { data, error } = await supabase
        .from("conversations")
        .select(
          `
          id,
          client_id,
          admin_id,
          client_profile:profiles!conversations_client_id_fkey(*),
          admin_profile:profiles!conversations_admin_id_fkey(*)
        `
        )
        .order("id", { ascending: false })

      if (error) {
        console.error("Erro ao buscar conversas:", error)
        return
      }

      setConversations(data || [])
    }

    fetchConversations()
  }, [supabase])

  const filtered = conversations.filter((c) => {
    const other = isAdmin ? c.client_profile : c.admin_profile
    const name = other?.full_name?.toLowerCase() || ""
    return name.includes(search.toLowerCase())
  })

  return (
    <div className="flex flex-col h-full bg-[#f0f2f5] border-r border-gray-200">
      <div className="p-4">
        <Input
          placeholder="Buscar..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <ScrollArea className="flex-1">
        <div className="space-y-1 px-2 pb-4">
          {filtered.map((conv) => {
            const other = isAdmin ? conv.client_profile : conv.admin_profile
            const active = conv.id === selectedConversationId

            return (
              <button
                key={conv.id}
                onClick={() => onSelectConversation(conv)}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left transition-colors ${
                  active ? "bg-white shadow-sm" : "hover:bg-gray-100"
                }`}
              >
                <Avatar className="h-10 w-10">
                  <AvatarImage src={other?.avatar_url || ""} />
                  <AvatarFallback>
                    {other?.full_name?.charAt(0) || "?"}
                  </AvatarFallback>
                </Avatar>

                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate">
                    {other?.full_name || "Usuário"}
                  </p>
                  <p className="text-xs text-gray-500 truncate">
                    {other?.email}
                  </p>
                </div>
              </button>
            )
          })}
        </div>
      </ScrollArea>
    </div>
  )
}
