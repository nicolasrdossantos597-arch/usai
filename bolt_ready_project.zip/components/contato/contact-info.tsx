import { Mail, Phone, MapPin, Clock } from "lucide-react"

export function ContactInfo() {
  const contactDetails = [
    {
      icon: Mail,
      title: "E-mail",
      value: "contato@uaisistemas.com.br",
      link: "mailto:contato@uaisistemas.com.br",
    },
    {
      icon: Phone,
      title: "Telefone",
      value: "(31) 3333-4444",
      link: "tel:+553133334444",
    },
    {
      icon: Phone,
      title: "WhatsApp",
      value: "(31) 99999-8888",
      link: "https://wa.me/5531999998888",
    },
    {
      icon: MapPin,
      title: "Endereço",
      value: "Rua Exemplo, 123 - Belo Horizonte, MG",
      link: null,
    },
  ]

  return (
    <div>
      <h2 className="text-3xl font-bold text-gray-900 mb-6">Informações de Contato</h2>
      <p className="text-gray-600 mb-8 leading-relaxed">
        Entre em contato conosco pelos canais abaixo ou preencha o formulário. Nossa equipe responde em até 24 horas.
      </p>

      <div className="space-y-6 mb-10">
        {contactDetails.map((detail, index) => (
          <div key={index} className="flex items-start gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-xl flex items-center justify-center flex-shrink-0">
              <detail.icon className="text-white" size={20} />
            </div>
            <div>
              <div className="font-bold text-gray-900 mb-1">{detail.title}</div>
              {detail.link ? (
                <a href={detail.link} className="text-blue-600 hover:text-blue-700">
                  {detail.value}
                </a>
              ) : (
                <div className="text-gray-600">{detail.value}</div>
              )}
            </div>
          </div>
        ))}

        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-500 rounded-xl flex items-center justify-center flex-shrink-0">
            <Clock className="text-white" size={20} />
          </div>
          <div>
            <div className="font-bold text-gray-900 mb-1">Horário de Atendimento</div>
            <div className="text-gray-600">Segunda a Sexta: 8h às 18h</div>
            <div className="text-gray-600">Suporte 24/7 para clientes</div>
          </div>
        </div>
      </div>

      {/* CTA Box */}
      <div className="bg-gradient-to-br from-blue-600 to-cyan-500 rounded-2xl p-8 text-white">
        <h3 className="text-2xl font-bold mb-3">Precisa de Atendimento Urgente?</h3>
        <p className="mb-6 text-blue-50">
          Para clientes com projetos em andamento, oferecemos suporte prioritário 24/7 via WhatsApp
        </p>
        <a
          href="https://wa.me/5531999998888"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-white text-blue-600 font-bold px-6 py-3 rounded-full hover:shadow-lg transition-all"
        >
          Falar no WhatsApp Agora
        </a>
      </div>
    </div>
  )
}
