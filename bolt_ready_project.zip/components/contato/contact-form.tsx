"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Send } from "lucide-react"

export function ContactForm() {
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setLoading(true)
    setError("")
    setSuccess(false)

    const formData = new FormData(e.currentTarget)
    const data = {
      name: formData.get("name"),
      email: formData.get("email"),
      phone: formData.get("phone"),
      company: formData.get("company"),
      message: formData.get("message"),
    }

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      })

      if (!response.ok) throw new Error("Erro ao enviar mensagem")

      setSuccess(true)
      ;(e.target as HTMLFormElement).reset()
    } catch (err) {
      setError("Erro ao enviar mensagem. Tente novamente.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-white rounded-2xl p-8 shadow-lg">
      <h2 className="text-3xl font-bold text-gray-900 mb-6">Envie sua Mensagem</h2>

      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
          <p className="text-green-700">Mensagem enviada com sucesso! Entraremos em contato em breve.</p>
        </div>
      )}

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-700">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <Label htmlFor="name">Nome Completo *</Label>
          <Input id="name" name="name" required className="mt-2" placeholder="João Silva" />
        </div>

        <div>
          <Label htmlFor="email">E-mail *</Label>
          <Input id="email" name="email" type="email" required className="mt-2" placeholder="joao@empresa.com" />
        </div>

        <div>
          <Label htmlFor="phone">Telefone *</Label>
          <Input id="phone" name="phone" required className="mt-2" placeholder="(31) 99999-9999" />
        </div>

        <div>
          <Label htmlFor="company">Empresa</Label>
          <Input id="company" name="company" className="mt-2" placeholder="Minha Empresa Ltda" />
        </div>

        <div>
          <Label htmlFor="message">Mensagem *</Label>
          <Textarea
            id="message"
            name="message"
            required
            className="mt-2 min-h-32"
            placeholder="Conte-nos sobre seu projeto ou necessidade..."
          />
        </div>

        <Button
          type="submit"
          disabled={loading}
          className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 py-6 text-lg"
        >
          {loading ? "Enviando..." : "Enviar Mensagem"}
          <Send className="ml-2" size={20} />
        </Button>
      </form>
    </div>
  )
}
