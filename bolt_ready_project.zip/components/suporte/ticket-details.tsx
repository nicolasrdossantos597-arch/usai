import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Ticket } from "@/lib/types"

interface TicketDetailsProps {
  ticket: Ticket
}

const statusMap = {
  open: { label: "Aberto", variant: "default" as const },
  in_progress: { label: "Em Andamento", variant: "secondary" as const },
  resolved: { label: "Resolvido", variant: "outline" as const },
  closed: { label: "Fechado", variant: "outline" as const },
}

const priorityMap = {
  low: { label: "Baixa", color: "bg-gray-100 text-gray-700" },
  medium: { label: "Média", color: "bg-blue-100 text-blue-700" },
  high: { label: "Alta", color: "bg-orange-100 text-orange-700" },
  urgent: { label: "Urgente", color: "bg-red-100 text-red-700" },
}

export function TicketDetails({ ticket }: TicketDetailsProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Detalhes do Ticket</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <p className="mb-1 text-sm font-medium text-gray-600">Título</p>
          <p className="text-sm text-gray-900">{ticket.title}</p>
        </div>

        <div>
          <p className="mb-1 text-sm font-medium text-gray-600">Status</p>
          <Badge variant={statusMap[ticket.status].variant}>{statusMap[ticket.status].label}</Badge>
        </div>

        <div>
          <p className="mb-1 text-sm font-medium text-gray-600">Prioridade</p>
          <Badge className={priorityMap[ticket.priority].color}>{priorityMap[ticket.priority].label}</Badge>
        </div>

        <div>
          <p className="mb-1 text-sm font-medium text-gray-600">Descrição</p>
          <p className="text-sm leading-relaxed text-gray-900">{ticket.description}</p>
        </div>

        {ticket.assigned_user && (
          <div>
            <p className="mb-1 text-sm font-medium text-gray-600">Atribuído para</p>
            <p className="text-sm text-gray-900">{ticket.assigned_user.full_name}</p>
          </div>
        )}

        <div>
          <p className="mb-1 text-sm font-medium text-gray-600">Criado em</p>
          <p className="text-sm text-gray-900">{new Date(ticket.created_at).toLocaleString("pt-BR")}</p>
        </div>

        {ticket.updated_at !== ticket.created_at && (
          <div>
            <p className="mb-1 text-sm font-medium text-gray-600">Última atualização</p>
            <p className="text-sm text-gray-900">{new Date(ticket.updated_at).toLocaleString("pt-BR")}</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
