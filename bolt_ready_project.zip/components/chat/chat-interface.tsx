"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Send, Paperclip, MessageSquare } from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import type { Profile } from "@/lib/types"

interface Message {
  id: string
  sender_id: string
  content: string
  created_at: string
  sender?: Profile
}

interface ChatInterfaceProps {
  profile: Profile
  chatRooms: any[]
}

export function ChatInterface({ profile, chatRooms }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [loading, setLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const supabase = createClient()

  // Get or create default chat room
  const chatRoomId = chatRooms[0]?.chat_room_id || null

  useEffect(() => {
    if (!chatRoomId) return

    // Load messages
    loadMessages()

    // Subscribe to new messages
    const channel = supabase
      .channel(`chat-${chatRoomId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "direct_messages",
          filter: `chat_room_id=eq.${chatRoomId}`,
        },
        (payload) => {
          loadMessages()
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [chatRoomId])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const loadMessages = async () => {
    if (!chatRoomId) return

    const { data } = await supabase
      .from("direct_messages")
      .select("*, sender:profiles(*)")
      .eq("chat_room_id", chatRoomId)
      .order("created_at", { ascending: true })

    if (data) {
      setMessages(data)
    }
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim() || !chatRoomId) return

    setLoading(true)

    const { error } = await supabase.from("direct_messages").insert({
      chat_room_id: chatRoomId,
      sender_id: profile.id,
      content: newMessage,
      message_type: "text",
    })

    if (!error) {
      setNewMessage("")
      loadMessages()
    }

    setLoading(false)
  }

  if (!chatRoomId) {
    return (
      <Card className="border-0 shadow-lg">
        <CardContent className="flex flex-col items-center justify-center py-16">
          <MessageSquare className="mb-4 h-16 w-16 text-gray-400" />
          <h3 className="mb-2 text-xl font-semibold text-gray-900">Chat não configurado</h3>
          <p className="text-gray-600">Entre em contato com o suporte para ativar o chat</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-0 shadow-lg h-[600px] flex flex-col">
      <CardContent className="flex-1 flex flex-col p-0">
        {/* Messages area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((message) => {
            const isOwn = message.sender_id === profile.id
            return (
              <div key={message.id} className={`flex gap-3 ${isOwn ? "flex-row-reverse" : ""}`}>
                <Avatar className="h-8 w-8 shrink-0">
                  <AvatarFallback className={isOwn ? "bg-blue-100 text-blue-600" : "bg-gray-100 text-gray-600"}>
                    {message.sender?.full_name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")
                      .toUpperCase()
                      .slice(0, 2) || "?"}
                  </AvatarFallback>
                </Avatar>
                <div className={`flex flex-col ${isOwn ? "items-end" : "items-start"} max-w-[70%]`}>
                  <div
                    className={`rounded-2xl px-4 py-2 ${isOwn ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-900"}`}
                  >
                    <p className="text-sm">{message.content}</p>
                  </div>
                  <span className="mt-1 text-xs text-gray-500">
                    {format(new Date(message.created_at), "HH:mm", { locale: ptBR })}
                  </span>
                </div>
              </div>
            )
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Input area */}
        <div className="border-t border-gray-200 p-4">
          <form onSubmit={handleSend} className="flex gap-2">
            <Button type="button" variant="outline" size="icon" className="shrink-0 bg-transparent">
              <Paperclip className="h-5 w-5" />
            </Button>
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Digite sua mensagem..."
              className="flex-1"
            />
            <Button type="submit" disabled={loading || !newMessage.trim()} size="icon" className="shrink-0">
              <Send className="h-5 w-5" />
            </Button>
          </form>
        </div>
      </CardContent>
    </Card>
  )
}
