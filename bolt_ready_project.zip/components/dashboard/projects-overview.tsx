import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { ArrowRight, FolderKanban } from "lucide-react"

interface Project {
  id: string
  name: string
  description?: string
  status: string
  progress: number
}

interface ProjectsOverviewProps {
  projects: Project[]
}

const statusLabels: Record<string, string> = {
  planning: "Planejamento",
  in_progress: "Em Andamento",
  testing: "Em Testes",
  completed: "Concluído",
  on_hold: "Pausado",
}

const statusColors: Record<string, string> = {
  planning: "bg-yellow-100 text-yellow-700",
  in_progress: "bg-blue-100 text-blue-700",
  testing: "bg-purple-100 text-purple-700",
  completed: "bg-green-100 text-green-700",
  on_hold: "bg-gray-100 text-gray-700",
}

export function ProjectsOverview({ projects }: ProjectsOverviewProps) {
  return (
    <Card className="border-0 shadow-lg shadow-gray-200/50">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Projetos Recentes</CardTitle>
          <CardDescription>Acompanhe o progresso dos seus projetos</CardDescription>
        </div>
        <Button variant="ghost" size="sm" asChild>
          <Link href="/dashboard/projetos">
            Ver Todos
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </CardHeader>
      <CardContent>
        {projects.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <FolderKanban className="mb-4 h-12 w-12 text-gray-400" />
            <p className="mb-2 text-sm font-medium text-gray-900">Nenhum projeto ainda</p>
            <p className="mb-4 text-sm text-gray-500">Comece criando seu primeiro projeto</p>
            <Button asChild>
              <Link href="/dashboard/projetos/novo">Criar Projeto</Link>
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {projects.map((project) => (
              <Link
                key={project.id}
                href={`/dashboard/projetos/${project.id}`}
                className="block rounded-lg border border-gray-200 p-4 transition-all hover:border-blue-300 hover:shadow-md"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900">{project.name}</h4>
                    {project.description && (
                      <p className="mt-1 text-sm text-gray-600 line-clamp-1">{project.description}</p>
                    )}
                  </div>
                  <span
                    className={`ml-2 rounded-full px-2.5 py-0.5 text-xs font-medium ${
                      statusColors[project.status] || statusColors.planning
                    }`}
                  >
                    {statusLabels[project.status] || project.status}
                  </span>
                </div>
                <div className="mt-3">
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-gray-600">Progresso</span>
                    <span className="font-medium text-gray-900">{project.progress}%</span>
                  </div>
                  <Progress value={project.progress} className="h-2" />
                </div>
              </Link>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
