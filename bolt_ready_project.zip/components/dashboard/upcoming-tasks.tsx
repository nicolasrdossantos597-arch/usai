import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, CheckCircle2 } from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

interface Task {
  id: string
  title: string
  description?: string
  status: string
  priority: string
  due_date?: string
  project?: {
    name: string
  }
}

interface UpcomingTasksProps {
  tasks: Task[]
}

const priorityColors: Record<string, string> = {
  low: "bg-gray-100 text-gray-700",
  medium: "bg-blue-100 text-blue-700",
  high: "bg-orange-100 text-orange-700",
  urgent: "bg-red-100 text-red-700",
}

const priorityLabels: Record<string, string> = {
  low: "Baixa",
  medium: "Média",
  high: "Alta",
  urgent: "Urgente",
}

export function UpcomingTasks({ tasks }: UpcomingTasksProps) {
  return (
    <Card className="border-0 shadow-lg shadow-gray-200/50">
      <CardHeader>
        <CardTitle>Tarefas Próximas</CardTitle>
        <CardDescription>Suas próximas tarefas e prazos</CardDescription>
      </CardHeader>
      <CardContent>
        {tasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <CheckCircle2 className="mb-3 h-10 w-10 text-green-500" />
            <p className="text-sm font-medium text-gray-900">Tudo em dia!</p>
            <p className="text-sm text-gray-500">Você não tem tarefas pendentes</p>
          </div>
        ) : (
          <div className="space-y-3">
            {tasks.map((task) => (
              <div
                key={task.id}
                className="rounded-lg border border-gray-200 p-3 hover:border-blue-200 hover:bg-blue-50/50 transition-colors"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 text-sm truncate">{task.title}</p>
                    {task.project && <p className="text-xs text-gray-500 mt-0.5">{task.project.name}</p>}
                  </div>
                  <Badge className={`shrink-0 ${priorityColors[task.priority]}`}>
                    {priorityLabels[task.priority] || task.priority}
                  </Badge>
                </div>
                {task.due_date && (
                  <div className="flex items-center gap-1.5 mt-2 text-xs text-gray-600">
                    <Calendar className="h-3 w-3" />
                    <span>{format(new Date(task.due_date), "dd 'de' MMMM", { locale: ptBR })}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
