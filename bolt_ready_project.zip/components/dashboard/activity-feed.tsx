import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Activity } from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

interface ActivityLog {
  id: string
  action_type: string
  description?: string
  created_at: string
}

interface ActivityFeedProps {
  activities: ActivityLog[]
}

const actionIcons: Record<string, string> = {
  login: "🔐",
  message_sent: "💬",
  file_uploaded: "📎",
  project_updated: "📋",
  ticket_created: "🎫",
  task_completed: "✅",
}

export function ActivityFeed({ activities }: ActivityFeedProps) {
  return (
    <Card className="border-0 shadow-lg shadow-gray-200/50">
      <CardHeader>
        <CardTitle>Atividade Recente</CardTitle>
        <CardDescription>Suas ações mais recentes</CardDescription>
      </CardHeader>
      <CardContent>
        {activities.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <Activity className="mb-3 h-10 w-10 text-gray-400" />
            <p className="text-sm text-gray-500">Nenhuma atividade registrada</p>
          </div>
        ) : (
          <div className="space-y-4">
            {activities.map((activity, index) => (
              <div key={activity.id} className="flex gap-3">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gray-100 text-lg">
                  {actionIcons[activity.action_type] || "📌"}
                </div>
                <div className="flex-1 space-y-1">
                  <p className="text-sm text-gray-900">{activity.description || activity.action_type}</p>
                  <p className="text-xs text-gray-500">
                    {format(new Date(activity.created_at), "dd/MM/yyyy 'às' HH:mm", {
                      locale: ptBR,
                    })}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
