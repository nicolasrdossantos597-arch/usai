import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, CheckCircle } from "lucide-react"
import type { ClientService } from "@/lib/types"

interface ServicesOverviewProps {
  services: ClientService[]
}

export function ServicesOverview({ services }: ServicesOverviewProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Meus Serviços</CardTitle>
        <CardDescription>Serviços contratados e seus detalhes</CardDescription>
      </CardHeader>
      <CardContent>
        {services.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <p className="mb-4 text-sm text-gray-600">Você ainda não possui serviços contratados</p>
            <Button asChild>
              <Link href="/#servicos">Ver Serviços Disponíveis</Link>
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {services.map((clientService) => (
              <div
                key={clientService.id}
                className="flex items-start justify-between rounded-lg border border-gray-200 p-4"
              >
                <div className="flex-1">
                  <div className="mb-1 flex items-center gap-2">
                    <h3 className="font-semibold text-gray-900">{clientService.service?.name}</h3>
                    <Badge variant="outline" className="border-green-500 text-green-700">
                      <CheckCircle className="mr-1 h-3 w-3" />
                      Ativo
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600">{clientService.service?.short_description}</p>
                  <p className="mt-2 text-xs text-gray-500">
                    Desde {new Date(clientService.started_at).toLocaleDateString("pt-BR")}
                  </p>
                </div>
              </div>
            ))}
            <Button variant="outline" className="w-full bg-transparent" asChild>
              <Link href="/#servicos">
                Ver Mais Serviços
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
