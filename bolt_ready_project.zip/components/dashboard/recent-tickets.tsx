import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Plus, ArrowRight } from "lucide-react"
import type { Ticket } from "@/lib/types"

interface RecentTicketsProps {
  tickets: Ticket[]
}

const statusMap = {
  open: { label: "Aberto", variant: "default" as const },
  in_progress: { label: "Em Andamento", variant: "secondary" as const },
  resolved: { label: "Resolvido", variant: "outline" as const },
  closed: { label: "Fechado", variant: "outline" as const },
}

const priorityMap = {
  low: { label: "Baixa", color: "text-gray-600" },
  medium: { label: "Média", color: "text-blue-600" },
  high: { label: "Alta", color: "text-orange-600" },
  urgent: { label: "Urgente", color: "text-red-600" },
}

export function RecentTickets({ tickets }: RecentTicketsProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Tickets Recentes</CardTitle>
            <CardDescription>Seus últimos chamados de suporte</CardDescription>
          </div>
          <Button size="sm" asChild>
            <Link href="/dashboard/suporte/novo">
              <Plus className="mr-1 h-4 w-4" />
              Novo
            </Link>
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {tickets.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <p className="mb-4 text-sm text-gray-600">Você ainda não possui tickets de suporte</p>
            <Button asChild>
              <Link href="/dashboard/suporte/novo">
                <Plus className="mr-2 h-4 w-4" />
                Criar Primeiro Ticket
              </Link>
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {tickets.map((ticket) => (
              <Link
                key={ticket.id}
                href={`/dashboard/suporte/${ticket.id}`}
                className="block rounded-lg border border-gray-200 p-4 transition-colors hover:bg-gray-50"
              >
                <div className="mb-2 flex items-start justify-between">
                  <h3 className="font-semibold text-gray-900">{ticket.title}</h3>
                  <Badge variant={statusMap[ticket.status].variant}>{statusMap[ticket.status].label}</Badge>
                </div>
                <p className="mb-2 line-clamp-2 text-sm text-gray-600">{ticket.description}</p>
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span className={priorityMap[ticket.priority].color}>
                    Prioridade: {priorityMap[ticket.priority].label}
                  </span>
                  <span>{new Date(ticket.created_at).toLocaleDateString("pt-BR")}</span>
                </div>
              </Link>
            ))}
            <Button variant="outline" className="w-full bg-transparent" asChild>
              <Link href="/dashboard/suporte">
                Ver Todos os Tickets
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
