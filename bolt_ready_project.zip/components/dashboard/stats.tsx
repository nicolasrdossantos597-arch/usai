import { Card, CardContent } from "@/components/ui/card"
import { Ticket, CheckCircle, Package } from "lucide-react"

interface DashboardStatsProps {
  openTickets: number
  activeServices: number
  totalServices: number
}

export function DashboardStats({ openTickets, activeServices, totalServices }: DashboardStatsProps) {
  return (
    <div className="grid gap-6 md:grid-cols-3">
      <Card>
        <CardContent className="flex items-center gap-4 p-6">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100">
            <Ticket className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-600">Tickets Abertos</p>
            <p className="text-2xl font-bold text-gray-900">{openTickets}</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex items-center gap-4 p-6">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-green-100">
            <CheckCircle className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-600">Serviços Ativos</p>
            <p className="text-2xl font-bold text-gray-900">{activeServices}</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex items-center gap-4 p-6">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-purple-100">
            <Package className="h-6 w-6 text-purple-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-600">Total de Serviços</p>
            <p className="text-2xl font-bold text-gray-900">{totalServices}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
