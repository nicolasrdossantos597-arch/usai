import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus, MessageSquarePlus, Upload, FileText } from "lucide-react"

export function QuickActions() {
  const actions = [
    {
      title: "Novo Projeto",
      description: "Iniciar um novo projeto",
      icon: Plus,
      href: "/dashboard/projetos/novo",
      color: "from-blue-500 to-blue-600",
    },
    {
      title: "Abrir Ticket",
      description: "Solicitar suporte técnico",
      icon: MessageSquarePlus,
      href: "/dashboard/suporte/novo",
      color: "from-purple-500 to-purple-600",
    },
    {
      title: "Enviar Arquivo",
      description: "Upload de documentos",
      icon: Upload,
      href: "/dashboard/documentos",
      color: "from-cyan-500 to-cyan-600",
    },
    {
      title: "Ver Faturas",
      description: "Acessar histórico",
      icon: FileText,
      href: "/dashboard/faturas",
      color: "from-green-500 to-green-600",
    },
  ]

  return (
    <Card className="border-0 shadow-lg shadow-gray-200/50">
      <CardHeader>
        <CardTitle>Ações Rápidas</CardTitle>
        <CardDescription>Acesse rapidamente as principais funcionalidades</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {actions.map((action) => {
            const Icon = action.icon
            return (
              <Link key={action.title} href={action.href}>
                <Button
                  variant="outline"
                  className="h-auto w-full flex-col items-start gap-2 p-4 hover:border-blue-200 hover:bg-blue-50 bg-transparent"
                >
                  <div className={`rounded-lg bg-gradient-to-br ${action.color} p-2`}>
                    <Icon className="h-5 w-5 text-white" />
                  </div>
                  <div className="text-left">
                    <p className="font-semibold text-gray-900">{action.title}</p>
                    <p className="text-xs text-gray-500">{action.description}</p>
                  </div>
                </Button>
              </Link>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
