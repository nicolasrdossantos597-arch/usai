import { FolderKanban, Ticket, MessageSquare, TrendingUp } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface StatsGridProps {
  activeProjects: number
  openTickets: number
  unreadMessages: number
}

export function StatsGrid({ activeProjects, openTickets, unreadMessages }: StatsGridProps) {
  const stats = [
    {
      label: "Projetos Ativos",
      value: activeProjects,
      icon: FolderKanban,
      color: "from-blue-500 to-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      label: "Tickets Abertos",
      value: openTickets,
      icon: Ticket,
      color: "from-purple-500 to-purple-600",
      bgColor: "bg-purple-50",
    },
    {
      label: "Mensagens Não Lidas",
      value: unreadMessages,
      icon: MessageSquare,
      color: "from-cyan-500 to-cyan-600",
      bgColor: "bg-cyan-50",
    },
    {
      label: "Taxa de Conclusão",
      value: "87%",
      icon: TrendingUp,
      color: "from-green-500 to-green-600",
      bgColor: "bg-green-50",
    },
  ]

  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => {
        const Icon = stat.icon
        return (
          <Card key={stat.label} className="overflow-hidden border-0 shadow-lg shadow-gray-200/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className="mt-2 text-3xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`rounded-2xl ${stat.bgColor} p-3`}>
                  <Icon className={`h-6 w-6 bg-gradient-to-br ${stat.color} bg-clip-text text-transparent`} />
                </div>
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
