-- Drop existing chat system tables and recreate simplified version
DROP TABLE IF EXISTS typing_indicators CASCADE;
DROP TABLE IF EXISTS direct_messages CASCADE;
DROP TABLE IF EXISTS chat_room_members CASCADE;
DROP TABLE IF EXISTS chat_rooms CASCADE;

-- Create simplified conversations table (1:1 between admin and client)
CREATE TABLE conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  admin_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  last_message_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create messages table
CREATE TABLE conversation_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  read_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create dashboard content table for admin customization
CREATE TABLE dashboard_content (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  section VARCHAR(50) NOT NULL UNIQUE,
  title TEXT,
  description TEXT,
  is_visible BOOLEAN DEFAULT TRUE,
  display_order INTEGER,
  content JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default dashboard sections
INSERT INTO dashboard_content (section, title, description, is_visible, display_order, content) VALUES
('welcome', 'Bem-vindo à UAI Sistemas', 'Gerencie seus projetos, tickets e comunicação em um só lugar.', TRUE, 1, '{}'),
('quick_actions', 'Ações Rápidas', NULL, TRUE, 2, '{}'),
('stats', 'Estatísticas', NULL, TRUE, 3, '{}'),
('projects', 'Projetos', 'Acompanhe o progresso dos seus projetos', TRUE, 4, '{}'),
('activity', 'Atividade Recente', NULL, TRUE, 5, '{}');

-- Create indexes
CREATE INDEX idx_conversations_client ON conversations(client_id);
CREATE INDEX idx_conversations_admin ON conversations(admin_id);
CREATE INDEX idx_messages_conversation ON conversation_messages(conversation_id);
CREATE INDEX idx_messages_sender ON conversation_messages(sender_id);
CREATE INDEX idx_messages_created ON conversation_messages(created_at DESC);

-- RLS Policies for conversations
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own conversations"
  ON conversations FOR SELECT
  USING (
    auth.uid() = client_id OR 
    auth.uid() = admin_id OR
    auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin')
  );

CREATE POLICY "Service role can manage conversations"
  ON conversations FOR ALL
  USING (auth.jwt()->>'role' = 'service_role');

-- RLS Policies for messages
ALTER TABLE conversation_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view messages from their conversations"
  ON conversation_messages FOR SELECT
  USING (
    conversation_id IN (
      SELECT id FROM conversations 
      WHERE client_id = auth.uid() OR admin_id = auth.uid()
    ) OR
    auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin')
  );

CREATE POLICY "Users can send messages to their conversations"
  ON conversation_messages FOR INSERT
  WITH CHECK (
    conversation_id IN (
      SELECT id FROM conversations 
      WHERE client_id = auth.uid() OR admin_id = auth.uid()
    ) OR
    auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin')
  );

CREATE POLICY "Users can update their own messages"
  ON conversation_messages FOR UPDATE
  USING (sender_id = auth.uid());

CREATE POLICY "Service role can manage messages"
  ON conversation_messages FOR ALL
  USING (auth.jwt()->>'role' = 'service_role');

-- RLS Policies for dashboard content
ALTER TABLE dashboard_content ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view dashboard content"
  ON dashboard_content FOR SELECT
  USING (TRUE);

CREATE POLICY "Service role can manage dashboard content"
  ON dashboard_content FOR ALL
  USING (auth.jwt()->>'role' = 'service_role');

-- Function to auto-create conversation when client first accesses dashboard
CREATE OR REPLACE FUNCTION create_client_conversation()
RETURNS TRIGGER AS $$
DECLARE
  admin_user_id UUID;
BEGIN
  -- Only create conversation for non-admin users
  IF NEW.role = 'client' THEN
    -- Get first admin user (you can modify this logic)
    SELECT id INTO admin_user_id 
    FROM profiles 
    WHERE role = 'admin' 
    LIMIT 1;
    
    -- Create conversation if doesn't exist
    IF admin_user_id IS NOT NULL THEN
      INSERT INTO conversations (client_id, admin_id)
      VALUES (NEW.id, admin_user_id)
      ON CONFLICT DO NOTHING;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to create conversation
DROP TRIGGER IF EXISTS trigger_create_conversation ON profiles;
CREATE TRIGGER trigger_create_conversation
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION create_client_conversation();

-- Update function for last_message_at
CREATE OR REPLACE FUNCTION update_conversation_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE conversations
  SET last_message_at = NEW.created_at,
      updated_at = NEW.created_at
  WHERE id = NEW.conversation_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_conversation
  AFTER INSERT ON conversation_messages
  FOR EACH ROW
  EXECUTE FUNCTION update_conversation_timestamp();
