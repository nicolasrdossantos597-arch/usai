-- Enable RLS on new tables
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_room_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE direct_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_uploads ENABLE ROW LEVEL SECURITY;
ALTER TABLE case_studies ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_log ENABLE ROW LEVEL SECURITY;

-- Companies policies
CREATE POLICY "Users can view their own company"
  ON companies FOR SELECT
  USING (
    id IN (SELECT company_id FROM profiles WHERE id = auth.uid())
    OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "Admins can manage companies"
  ON companies FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

-- Projects policies
CREATE POLICY "Users can view their company projects"
  ON projects FOR SELECT
  USING (
    user_id = auth.uid()
    OR company_id IN (SELECT company_id FROM profiles WHERE id = auth.uid())
    OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'support'))
  );

CREATE POLICY "Admins can manage all projects"
  ON projects FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'support')));

-- Project tasks policies
CREATE POLICY "Users can view tasks from their projects"
  ON project_tasks FOR SELECT
  USING (
    project_id IN (
      SELECT id FROM projects WHERE user_id = auth.uid() 
      OR company_id IN (SELECT company_id FROM profiles WHERE id = auth.uid())
    )
    OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'support'))
  );

CREATE POLICY "Admins can manage project tasks"
  ON project_tasks FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'support')));

-- Chat rooms policies
CREATE POLICY "Users can view their chat rooms"
  ON chat_rooms FOR SELECT
  USING (
    id IN (SELECT chat_room_id FROM chat_room_members WHERE user_id = auth.uid())
    OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'support'))
  );

CREATE POLICY "Admins can manage chat rooms"
  ON chat_rooms FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'support')));

-- Chat room members policies
CREATE POLICY "Users can view members of their chat rooms"
  ON chat_room_members FOR SELECT
  USING (
    chat_room_id IN (SELECT chat_room_id FROM chat_room_members WHERE user_id = auth.uid())
    OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'support'))
  );

CREATE POLICY "Admins can manage chat room members"
  ON chat_room_members FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'support')));

-- Direct messages policies
CREATE POLICY "Users can view messages from their chat rooms"
  ON direct_messages FOR SELECT
  USING (
    chat_room_id IN (SELECT chat_room_id FROM chat_room_members WHERE user_id = auth.uid())
    OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'support'))
  );

CREATE POLICY "Users can send messages to their chat rooms"
  ON direct_messages FOR INSERT
  WITH CHECK (
    sender_id = auth.uid()
    AND chat_room_id IN (SELECT chat_room_id FROM chat_room_members WHERE user_id = auth.uid())
  );

CREATE POLICY "Admins can manage all messages"
  ON direct_messages FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'support')));

-- File uploads policies
CREATE POLICY "Users can view their own files"
  ON file_uploads FOR SELECT
  USING (
    user_id = auth.uid()
    OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'support'))
  );

CREATE POLICY "Users can upload files"
  ON file_uploads FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can manage all files"
  ON file_uploads FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'support')));

-- Case studies policies (public read)
CREATE POLICY "Anyone can view case studies"
  ON case_studies FOR SELECT
  USING (TRUE);

CREATE POLICY "Admins can manage case studies"
  ON case_studies FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

-- Activity log policies
CREATE POLICY "Users can view their own activity"
  ON activity_log FOR SELECT
  USING (user_id = auth.uid() OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'support')));

CREATE POLICY "Users can create their own activity"
  ON activity_log FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can view all activity"
  ON activity_log FOR ALL
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'support')));
