-- Fix RLS policies to avoid recursion and ensure messaging works properly

-- Drop all problematic policies on conversations and messages
DROP POLICY IF EXISTS "Users can view their own conversations" ON conversations;
DROP POLICY IF EXISTS "Service role can manage conversations" ON conversations;
DROP POLICY IF EXISTS "Allow users to view their conversations" ON conversations;
DROP POLICY IF EXISTS "Allow system to manage conversations" ON conversations;

DROP POLICY IF EXISTS "Users can view messages from their conversations" ON conversation_messages;
DROP POLICY IF EXISTS "Users can send messages to their conversations" ON conversation_messages;
DROP POLICY IF EXISTS "Users can update their own messages" ON conversation_messages;
DROP POLICY IF EXISTS "Service role can manage messages" ON conversation_messages;
DROP POLICY IF EXISTS "Allow users to view their conversation messages" ON conversation_messages;
DROP POLICY IF EXISTS "Allow users to send messages" ON conversation_messages;
DROP POLICY IF EXISTS "Allow users to update message read status" ON conversation_messages;

-- Create simple, non-recursive policies for conversations
-- Policy 1: Users can view conversations where they are the client
CREATE POLICY "view_own_client_conversations"
  ON conversations FOR SELECT
  USING (auth.uid() = client_id);

-- Policy 2: Users can view conversations where they are the admin
CREATE POLICY "view_admin_conversations"
  ON conversations FOR SELECT
  USING (auth.uid() = admin_id);

-- Policy 3: Allow inserting new conversations
CREATE POLICY "create_conversations"
  ON conversations FOR INSERT
  WITH CHECK (auth.uid() = client_id OR auth.uid() = admin_id);

-- Policy 4: Allow updating conversations (for last_message_at)
CREATE POLICY "update_conversations"
  ON conversations FOR UPDATE
  USING (auth.uid() = client_id OR auth.uid() = admin_id);

-- Create simple, non-recursive policies for messages
-- Policy 1: View messages in conversations where user is client
CREATE POLICY "view_messages_as_client"
  ON conversation_messages FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM conversations 
      WHERE conversations.id = conversation_messages.conversation_id 
      AND conversations.client_id = auth.uid()
    )
  );

-- Policy 2: View messages in conversations where user is admin
CREATE POLICY "view_messages_as_admin"
  ON conversation_messages FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM conversations 
      WHERE conversations.id = conversation_messages.conversation_id 
      AND conversations.admin_id = auth.uid()
    )
  );

-- Policy 3: Send messages in conversations where user is client
CREATE POLICY "send_messages_as_client"
  ON conversation_messages FOR INSERT
  WITH CHECK (
    auth.uid() = sender_id AND
    EXISTS (
      SELECT 1 FROM conversations 
      WHERE conversations.id = conversation_messages.conversation_id 
      AND conversations.client_id = auth.uid()
    )
  );

-- Policy 4: Send messages in conversations where user is admin
CREATE POLICY "send_messages_as_admin"
  ON conversation_messages FOR INSERT
  WITH CHECK (
    auth.uid() = sender_id AND
    EXISTS (
      SELECT 1 FROM conversations 
      WHERE conversations.id = conversation_messages.conversation_id 
      AND conversations.admin_id = auth.uid()
    )
  );

-- Policy 5: Update read status of messages
CREATE POLICY "update_message_read_status"
  ON conversation_messages FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM conversations 
      WHERE conversations.id = conversation_messages.conversation_id 
      AND (conversations.client_id = auth.uid() OR conversations.admin_id = auth.uid())
    )
  );

-- Ensure conversations are created for existing users who don't have one yet
DO $$
DECLARE
  admin_user_id UUID;
  client_record RECORD;
BEGIN
  -- Get the admin user
  SELECT id INTO admin_user_id 
  FROM auth.users 
  WHERE email = 'usaisistemasbr@gmail.com';
  
  IF admin_user_id IS NOT NULL THEN
    -- Create conversations for all clients that don't have one
    FOR client_record IN 
      SELECT p.id 
      FROM profiles p
      WHERE p.role = 'client' 
      AND NOT EXISTS (
        SELECT 1 FROM conversations c WHERE c.client_id = p.id
      )
    LOOP
      INSERT INTO conversations (client_id, admin_id)
      VALUES (client_record.id, admin_user_id)
      ON CONFLICT DO NOTHING;
    END LOOP;
    
    RAISE NOTICE 'Conversations created for existing clients';
  ELSE
    RAISE NOTICE 'Admin user not found. Please ensure usaisistemasbr@gmail.com is registered and has admin role.';
  END IF;
END $$;
