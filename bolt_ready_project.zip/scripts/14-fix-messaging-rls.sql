-- Fix RLS policies for messaging to work properly
-- Drop problematic policies and create simple ones

-- Drop all existing policies on conversations
DROP POLICY IF EXISTS "Users can view their own conversations" ON conversations;
DROP POLICY IF EXISTS "Service role can manage conversations" ON conversations;

-- Drop all existing policies on conversation_messages  
DROP POLICY IF EXISTS "Users can view messages from their conversations" ON conversation_messages;
DROP POLICY IF EXISTS "Users can send messages to their conversations" ON conversation_messages;
DROP POLICY IF EXISTS "Users can update their own messages" ON conversation_messages;
DROP POLICY IF EXISTS "Service role can manage messages" ON conversation_messages;

-- Create simple, non-recursive policies for conversations
CREATE POLICY "Allow users to view their conversations"
  ON conversations FOR SELECT
  USING (
    client_id = auth.uid() OR 
    admin_id = auth.uid()
  );

CREATE POLICY "Allow system to manage conversations"
  ON conversations FOR ALL
  USING (true)
  WITH CHECK (true);

-- Create simple policies for messages
CREATE POLICY "Allow users to view their conversation messages"
  ON conversation_messages FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM conversations 
      WHERE id = conversation_id 
      AND (client_id = auth.uid() OR admin_id = auth.uid())
    )
  );

CREATE POLICY "Allow users to send messages"
  ON conversation_messages FOR INSERT
  WITH CHECK (
    sender_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM conversations 
      WHERE id = conversation_id 
      AND (client_id = auth.uid() OR admin_id = auth.uid())
    )
  );

CREATE POLICY "Allow users to update message read status"
  ON conversation_messages FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM conversations 
      WHERE id = conversation_id 
      AND (client_id = auth.uid() OR admin_id = auth.uid())
    )
  );

-- Ensure trigger exists to create conversation for new clients
CREATE OR REPLACE FUNCTION ensure_client_conversation()
RETURNS TRIGGER AS $$
DECLARE
  admin_user_id UUID;
BEGIN
  -- Only for non-admin users
  IF NEW.role != 'admin' THEN
    -- Get first admin user
    SELECT id INTO admin_user_id 
    FROM profiles 
    WHERE role = 'admin' 
    LIMIT 1;
    
    -- Create conversation if admin exists
    IF admin_user_id IS NOT NULL THEN
      INSERT INTO conversations (client_id, admin_id, created_at, updated_at)
      VALUES (NEW.id, admin_user_id, NOW(), NOW())
      ON CONFLICT DO NOTHING;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate trigger
DROP TRIGGER IF EXISTS trigger_ensure_conversation ON profiles;
CREATE TRIGGER trigger_ensure_conversation
  AFTER INSERT OR UPDATE OF role ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION ensure_client_conversation();
