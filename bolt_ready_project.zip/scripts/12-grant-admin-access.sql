-- Grant admin access to usaisistemasbr@gmail.com
-- This script updates the profile to set role as 'admin'

-- First, find the user ID from auth.users
DO $$
DECLARE
  target_user_id uuid;
BEGIN
  -- Get the user ID from auth.users
  SELECT id INTO target_user_id
  FROM auth.users
  WHERE email = 'usaisistemasbr@gmail.com';

  -- If user exists, update their profile
  IF target_user_id IS NOT NULL THEN
    -- Update existing profile or insert if doesn't exist
    INSERT INTO profiles (id, email, role, full_name, created_at, updated_at)
    VALUES (
      target_user_id,
      'usaisistemasbr@gmail.com',
      'admin',
      'UAI Sistemas Admin',
      NOW(),
      NOW()
    )
    ON CONFLICT (id) 
    DO UPDATE SET 
      role = 'admin',
      updated_at = NOW();

    RAISE NOTICE 'Admin access granted to usaisistemasbr@gmail.com (ID: %)', target_user_id;
  ELSE
    RAISE NOTICE 'User with email usaisistemasbr@gmail.com not found. They need to sign up first.';
  END IF;
END $$;

-- Verify the change
SELECT id, email, full_name, role, created_at, updated_at
FROM profiles
WHERE email = 'usaisistemasbr@gmail.com';
