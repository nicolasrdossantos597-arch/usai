-- Insert sample case studies
INSERT INTO case_studies (company_name, industry, challenge, solution, results, metrics, testimonial, testimonial_author, testimonial_role, featured, display_order) VALUES
('Tech Innovations Ltda', 'Tecnologia', 
 'Processos manuais causavam atrasos e erros frequentes na gestão de projetos.',
 'Implementamos sistema de gestão integrado com automação de tarefas e relatórios em tempo real.',
 'Redução de 60% no tempo de gestão, aumento de 150% na produtividade da equipe.',
 '{"time_reduction": "60%", "productivity": "150%", "error_reduction": "80%"}',
 'A UAI Sistemas transformou completamente nossa operação. Agora temos visibilidade total dos projetos.',
 'Carlos Silva', 'CEO', TRUE, 1),

('Loja Virtual Plus', 'E-commerce',
 'Sistema antigo limitava crescimento e causava perda de vendas.',
 'Desenvolvemos plataforma e-commerce moderna com integração completa de pagamentos e estoque.',
 'Aumento de 200% nas vendas online, redução de 70% em tempo de processamento.',
 '{"sales_increase": "200%", "processing_time": "70%", "customer_satisfaction": "95%"}',
 'Nossa empresa cresceu exponencialmente após a implementação do novo sistema.',
 'Maria Santos', 'Diretora Comercial', TRUE, 2),

('Clínica Saúde Total', 'Saúde',
 'Agendamento manual gerava confusão e insatisfação dos pacientes.',
 'Sistema de agendamento online com lembretes automáticos e gestão de consultas.',
 'Redução de 85% em no-shows, aumento de 40% na capacidade de atendimento.',
 '{"no_show_reduction": "85%", "capacity_increase": "40%", "satisfaction": "92%"}',
 'O sistema revolucionou nossa gestão. Pacientes adoram a praticidade.',
 'Dr. João Oliveira', 'Diretor Médico', TRUE, 3);

-- Insert sample company
INSERT INTO companies (name, slug, description, is_active) VALUES
('Empresa Demo Ltda', 'empresa-demo', 'Empresa de demonstração do sistema', TRUE);
