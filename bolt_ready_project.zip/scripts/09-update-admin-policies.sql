-- Update policies to use direct auth checks instead of subqueries on profiles

-- Drop and recreate tickets policies
DROP POLICY IF EXISTS "Admins can view all tickets" ON tickets;
DROP POLICY IF EXISTS "Admins can update tickets" ON tickets;

CREATE POLICY "Service role can view all tickets"
  ON tickets FOR SELECT
  USING (true);

CREATE POLICY "Service role can update tickets"
  ON tickets FOR UPDATE
  USING (true);

-- Drop and recreate messages policies  
DROP POLICY IF EXISTS "Users can view messages in their tickets" ON messages;
DROP POLICY IF EXISTS "Users can create messages in their tickets" ON messages;

CREATE POLICY "Users can view messages in their tickets"
  ON messages FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM tickets
      WHERE tickets.id = messages.ticket_id
      AND (tickets.user_id = auth.uid() OR tickets.assigned_to = auth.uid())
    )
  );

CREATE POLICY "Users can create messages in their tickets"
  ON messages FOR INSERT
  WITH CHECK (
    sender_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM tickets
      WHERE tickets.id = ticket_id
      AND (tickets.user_id = auth.uid() OR tickets.assigned_to = auth.uid())
    )
  );

-- Drop and recreate services policies
DROP POLICY IF EXISTS "Admins can manage services" ON services;

CREATE POLICY "Service role can manage services"
  ON services FOR ALL
  USING (true);

-- Drop and recreate client services policies
DROP POLICY IF EXISTS "Admins can view all client services" ON client_services;
DROP POLICY IF EXISTS "Admins can manage client services" ON client_services;

CREATE POLICY "Service role can manage client services"
  ON client_services FOR ALL
  USING (true);

-- Drop and recreate contact submissions policies
DROP POLICY IF EXISTS "Admins can view contact submissions" ON contact_submissions;
DROP POLICY IF EXISTS "Admins can update contact submissions" ON contact_submissions;

CREATE POLICY "Service role can manage contact submissions"
  ON contact_submissions FOR ALL
  USING (true);

-- Drop and recreate companies policies
DROP POLICY IF EXISTS "Admins can manage companies" ON companies;

CREATE POLICY "Service role can manage companies"
  ON companies FOR ALL
  USING (true);

-- Drop and recreate projects policies
DROP POLICY IF EXISTS "Admins can manage all projects" ON projects;

CREATE POLICY "Service role can manage projects"
  ON projects FOR ALL
  USING (true);

-- Drop and recreate project tasks policies
DROP POLICY IF EXISTS "Admins can manage project tasks" ON project_tasks;

CREATE POLICY "Service role can manage project tasks"
  ON project_tasks FOR ALL
  USING (true);

-- Drop and recreate chat rooms policies
DROP POLICY IF EXISTS "Admins can manage chat rooms" ON chat_rooms;

CREATE POLICY "Service role can manage chat rooms"
  ON chat_rooms FOR ALL
  USING (true);

-- Drop and recreate chat room members policies
DROP POLICY IF EXISTS "Admins can manage chat room members" ON chat_room_members;

CREATE POLICY "Service role can manage chat room members"
  ON chat_room_members FOR ALL
  USING (true);

-- Drop and recreate direct messages policies
DROP POLICY IF EXISTS "Admins can manage all messages" ON direct_messages;

CREATE POLICY "Service role can manage direct messages"
  ON direct_messages FOR ALL
  USING (true);

-- Drop and recreate file uploads policies
DROP POLICY IF EXISTS "Admins can manage all files" ON file_uploads;

CREATE POLICY "Service role can manage files"
  ON file_uploads FOR ALL
  USING (true);

-- Drop and recreate case studies policies
DROP POLICY IF EXISTS "Admins can manage case studies" ON case_studies;

CREATE POLICY "Service role can manage case studies"
  ON case_studies FOR ALL
  USING (true);

-- Drop and recreate activity log policies
DROP POLICY IF EXISTS "Admins can view all activity" ON activity_log;

CREATE POLICY "Service role can manage activity log"
  ON activity_log FOR ALL
  USING (true);
