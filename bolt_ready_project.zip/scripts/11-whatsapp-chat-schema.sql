-- Atualizar tabelas existentes e adicionar funcionalidades de mensagens estilo WhatsApp

-- Adicionar campos adicionais em profiles se não existirem
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS is_online boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS last_seen timestamp with time zone DEFAULT now();

-- Atualizar chat_rooms para ter mais informações
ALTER TABLE chat_rooms 
ADD COLUMN IF NOT EXISTS avatar_url text,
ADD COLUMN IF NOT EXISTS last_message_at timestamp with time zone,
ADD COLUMN IF NOT EXISTS is_active boolean DEFAULT true;

-- Atualizar direct_messages para adicionar status de leitura e digitação
ALTER TABLE direct_messages
ADD COLUMN IF NOT EXISTS edited_at timestamp with time zone,
ADD COLUMN IF NOT EXISTS is_deleted boolean DEFAULT false;

-- Criar tabela para controlar quem está digitando
CREATE TABLE IF NOT EXISTS typing_indicators (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_room_id uuid REFERENCES chat_rooms(id) ON DELETE CASCADE,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamp with time zone DEFAULT now(),
  UNIQUE(chat_room_id, user_id)
);

-- RLS para typing_indicators
ALTER TABLE typing_indicators ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view typing in their rooms" ON typing_indicators;
CREATE POLICY "Users can view typing in their rooms"
  ON typing_indicators FOR SELECT
  USING (
    chat_room_id IN (
      SELECT chat_room_id FROM chat_room_members WHERE user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Users can insert their typing status" ON typing_indicators;
CREATE POLICY "Users can insert their typing status"
  ON typing_indicators FOR INSERT
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "Users can delete their typing status" ON typing_indicators;
CREATE POLICY "Users can delete their typing status"
  ON typing_indicators FOR DELETE
  USING (user_id = auth.uid());

DROP POLICY IF EXISTS "Service role can manage typing indicators" ON typing_indicators;
CREATE POLICY "Service role can manage typing indicators"
  ON typing_indicators FOR ALL
  USING (true);

-- Atualizar RLS para chat_rooms (admin vê tudo, usuários veem suas salas)
DROP POLICY IF EXISTS "Users can view their chat rooms" ON chat_rooms;
CREATE POLICY "Users can view their chat rooms"
  ON chat_rooms FOR SELECT
  USING (
    id IN (
      SELECT chat_room_id FROM chat_room_members WHERE user_id = auth.uid()
    )
  );

-- Atualizar RLS para chat_room_members
DROP POLICY IF EXISTS "Users can view members of their chat rooms" ON chat_room_members;
CREATE POLICY "Users can view members of their chat rooms"
  ON chat_room_members FOR SELECT
  USING (
    chat_room_id IN (
      SELECT chat_room_id FROM chat_room_members WHERE user_id = auth.uid()
    )
  );

-- Atualizar RLS para direct_messages
DROP POLICY IF EXISTS "Users can view messages from their chat rooms" ON direct_messages;
CREATE POLICY "Users can view messages from their chat rooms"
  ON direct_messages FOR SELECT
  USING (
    chat_room_id IN (
      SELECT chat_room_id FROM chat_room_members WHERE user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Users can send messages to their chat rooms" ON direct_messages;
CREATE POLICY "Users can send messages to their chat rooms"
  ON direct_messages FOR INSERT
  WITH CHECK (
    sender_id = auth.uid() AND
    chat_room_id IN (
      SELECT chat_room_id FROM chat_room_members WHERE user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Users can update own messages" ON direct_messages;
CREATE POLICY "Users can update own messages"
  ON direct_messages FOR UPDATE
  USING (sender_id = auth.uid());

-- Função para criar sala de chat individual entre dois usuários
CREATE OR REPLACE FUNCTION get_or_create_direct_chat(user1_id uuid, user2_id uuid)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  room_id uuid;
BEGIN
  -- Procurar sala existente entre os dois usuários
  SELECT cr.id INTO room_id
  FROM chat_rooms cr
  WHERE cr.is_group = false
    AND EXISTS (
      SELECT 1 FROM chat_room_members WHERE chat_room_id = cr.id AND user_id = user1_id
    )
    AND EXISTS (
      SELECT 1 FROM chat_room_members WHERE chat_room_id = cr.id AND user_id = user2_id
    );

  -- Se não existir, criar nova sala
  IF room_id IS NULL THEN
    INSERT INTO chat_rooms (name, is_group, created_by)
    VALUES ('Direct Chat', false, user1_id)
    RETURNING id INTO room_id;

    -- Adicionar ambos usuários à sala
    INSERT INTO chat_room_members (chat_room_id, user_id)
    VALUES (room_id, user1_id), (room_id, user2_id);
  END IF;

  RETURN room_id;
END;
$$;

-- Função para atualizar last_message_at quando nova mensagem é enviada
CREATE OR REPLACE FUNCTION update_chat_room_last_message()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE chat_rooms
  SET last_message_at = NEW.created_at
  WHERE id = NEW.chat_room_id;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_update_chat_room_last_message ON direct_messages;
CREATE TRIGGER trigger_update_chat_room_last_message
  AFTER INSERT ON direct_messages
  FOR EACH ROW
  EXECUTE FUNCTION update_chat_room_last_message();

-- Criar sala de chat automática entre admin e cada cliente
DO $$
DECLARE
  admin_id uuid;
  client_record RECORD;
  room_id uuid;
BEGIN
  -- Pegar ID do admin
  SELECT id INTO admin_id FROM profiles WHERE role = 'admin' LIMIT 1;
  
  IF admin_id IS NOT NULL THEN
    -- Para cada cliente, criar sala com admin
    FOR client_record IN
      SELECT id FROM profiles WHERE role = 'client'
    LOOP
      -- Verificar se já existe sala entre admin e cliente
      SELECT cr.id INTO room_id
      FROM chat_rooms cr
      WHERE cr.is_group = false
        AND EXISTS (SELECT 1 FROM chat_room_members WHERE chat_room_id = cr.id AND user_id = admin_id)
        AND EXISTS (SELECT 1 FROM chat_room_members WHERE chat_room_id = cr.id AND user_id = client_record.id);
      
      -- Se não existir, criar
      IF room_id IS NULL THEN
        room_id := get_or_create_direct_chat(admin_id, client_record.id);
      END IF;
    END LOOP;
  END IF;
END $$;
