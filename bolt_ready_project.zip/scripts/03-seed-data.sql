-- Insert sample services
INSERT INTO services (name, description, short_description, icon, price_info, features, display_order) VALUES
(
  'Desenvolvimento de Software',
  'Desenvolvimento de soluções sob medida para sua empresa, desde sistemas web até aplicativos móveis. Nossa equipe experiente utiliza as tecnologias mais modernas para criar softwares escaláveis e de alta performance.',
  'Soluções customizadas para seu negócio',
  'code',
  'A partir de R$ 5.000',
  ARRAY['Desenvolvimento Web', 'Aplicativos Móveis', 'APIs REST', 'Integração de Sistemas', 'Manutenção e Suporte'],
  1
),
(
  'Consultoria em TI',
  'Consultoria especializada para otimizar seus processos tecnológicos e aumentar a eficiência da sua empresa. Análise completa da infraestrutura atual e recomendações estratégicas para crescimento.',
  'Otimize sua infraestrutura tecnológica',
  'users',
  'Sob consulta',
  ARRAY['Auditoria de Sistemas', 'Planejamento Estratégico', 'Análise de Performance', 'Gestão de Projetos', 'Treinamento de Equipes'],
  2
),
(
  'Suporte Técnico',
  'Suporte técnico 24/7 para manter seus sistemas funcionando sem interrupções. Nossa equipe está sempre disponível para resolver problemas e garantir a continuidade do seu negócio.',
  'Suporte 24/7 para seu negócio',
  'headphones',
  'Planos a partir de R$ 500/mês',
  ARRAY['Atendimento 24/7', 'SLA Garantido', 'Monitoramento Proativo', 'Manutenção Preventiva', 'Correção de Bugs'],
  3
),
(
  'Cloud Computing',
  'Migração e gestão de infraestrutura em nuvem para aumentar a escalabilidade e reduzir custos operacionais. Trabalhamos com as principais plataformas do mercado.',
  'Leve sua infraestrutura para a nuvem',
  'cloud',
  'Sob consulta',
  ARRAY['Migração para Cloud', 'AWS/Azure/GCP', 'DevOps', 'Backup Automático', 'Escalabilidade'],
  4
),
(
  'Segurança da Informação',
  'Proteja seus dados e sistemas com nossas soluções completas de segurança. Implementamos as melhores práticas e tecnologias para manter sua empresa segura.',
  'Proteja seus dados e sistemas',
  'shield',
  'A partir de R$ 3.000/mês',
  ARRAY['Firewall e Antivírus', 'Gestão de Vulnerabilidades', 'Backup e Recuperação', 'Compliance', 'Treinamento de Segurança'],
  5
);
