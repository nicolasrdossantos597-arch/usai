export type UserRole = "client" | "admin" | "support"

export type TicketStatus = "open" | "in_progress" | "resolved" | "closed"

export type TicketPriority = "low" | "medium" | "high" | "urgent"

export type MessageType = "text" | "file" | "system"

export interface Profile {
  id: string
  email: string
  full_name: string
  role: UserRole
  company_name?: string
  phone?: string
  avatar_url?: string
  created_at: string
  updated_at: string
}

export interface Ticket {
  id: string
  user_id: string
  title: string
  description: string
  status: TicketStatus
  priority: TicketPriority
  assigned_to?: string
  created_at: string
  updated_at: string
  user?: Profile
  assigned_user?: Profile
  messages?: Message[]
}

export interface Message {
  id: string
  ticket_id: string
  sender_id: string
  content: string
  message_type: MessageType
  file_url?: string
  file_name?: string
  is_read: boolean
  created_at: string
  sender?: Profile
}

export interface Service {
  id: string
  name: string
  description: string
  short_description?: string
  icon?: string
  price_info?: string
  features?: string[]
  is_active: boolean
  display_order: number
  created_at: string
  updated_at: string
}

export interface ClientService {
  id: string
  user_id: string
  service_id: string
  status: string
  started_at: string
  ended_at?: string
  created_at: string
  updated_at: string
  service?: Service
}

export interface ContactSubmission {
  id: string
  name: string
  email: string
  phone?: string
  company?: string
  subject: string
  message: string
  is_processed: boolean
  created_at: string
}

export interface Project {
  id: string
  company_id?: string
  user_id: string
  name: string
  description?: string
  status: string
  progress: number
  estimated_completion_date?: string
  started_at?: string
  completed_at?: string
  created_at: string
  updated_at: string
}

export interface ProjectTask {
  id: string
  project_id: string
  title: string
  description?: string
  status: string
  priority: TicketPriority
  assigned_to?: string
  completed_at?: string
  due_date?: string
  created_at: string
  updated_at: string
  project?: {
    name: string
  }
}

export interface ChatRoom {
  id: string
  company_id?: string
  name: string
  description?: string
  is_group: boolean
  created_by?: string
  created_at: string
  updated_at: string
}

export interface DirectMessage {
  id: string
  chat_room_id: string
  sender_id: string
  content: string
  message_type: MessageType
  file_url?: string
  file_name?: string
  is_read: boolean
  read_at?: string
  created_at: string
  sender?: Profile
}

export interface FileUpload {
  id: string
  user_id: string
  project_id?: string
  file_name: string
  file_url: string
  file_size?: number
  file_type?: string
  description?: string
  created_at: string
  project?: {
    name: string
  }
}

export interface ActivityLog {
  id: string
  user_id: string
  action_type: string
  description?: string
  metadata?: any
  created_at: string
}
