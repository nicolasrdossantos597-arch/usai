import { Navbar } from "@/components/shared/navbar"
import { Footer } from "@/components/shared/footer"
import { CasesHero } from "@/components/cases/cases-hero"
import { CasesList } from "@/components/cases/cases-list"
import { ResultsSection } from "@/components/cases/results-section"

export default function CasesPage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <CasesHero />
      <CasesList />
      <ResultsSection />
      <Footer />
    </main>
  )
}
