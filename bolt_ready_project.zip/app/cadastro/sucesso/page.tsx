import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"

export default function SignUpSuccessPage() {
  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-gray-50 p-6">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <Link href="/" className="inline-flex items-center gap-3">
            <img src="/images/logo.png" alt="Usai Sistemas" className="w-12 h-12" />
            <span className="text-2xl font-bold text-gray-900">Usai Sistemas</span>
          </Link>
        </div>

        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <CardTitle className="text-2xl">Cadastro realizado com sucesso!</CardTitle>
            <CardDescription>Verifique seu e-mail para confirmar sua conta</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-center text-sm leading-relaxed text-muted-foreground">
              Enviamos um e-mail de confirmação para o endereço cadastrado. Clique no link do e-mail para ativar sua
              conta e começar a usar nossos serviços.
            </p>
            <div className="rounded-lg bg-blue-50 p-4">
              <p className="text-sm text-blue-900">
                <strong>Importante:</strong> Verifique sua caixa de spam caso não encontre o e-mail na caixa de entrada.
              </p>
            </div>
            <Button asChild className="w-full">
              <Link href="/login">Ir para Login</Link>
            </Button>
          </CardContent>
        </Card>

        <div className="mt-4 text-center">
          <Link href="/" className="text-sm text-gray-600 hover:text-gray-900">
            ← Voltar para o site
          </Link>
        </div>
      </div>
    </div>
  )
}
