import { Navbar } from "@/components/shared/navbar"
import { Footer } from "@/components/shared/footer"
import { AboutHero } from "@/components/sobre/about-hero"
import { Timeline } from "@/components/sobre/timeline"
import { Team } from "@/components/sobre/team"
import { Values } from "@/components/sobre/values"

export default function SobrePage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <AboutHero />
      <Values />
      <Timeline />
      <Team />
      <Footer />
    </main>
  )
}
