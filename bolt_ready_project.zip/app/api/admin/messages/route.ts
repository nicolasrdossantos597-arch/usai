// app/api/messages/route.ts
import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  try {
    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });

    const data = await request.json();
    const { conversation_id, content } = data;

    if (!conversation_id || !content) {
      return NextResponse.json({ error: "Dados inválidos" }, { status: 400 });
    }

    // Verifica se o usuário pertence à conversa (client_id ou admin_id)
    const { data: conv, error: convErr } = await supabase
      .from("conversations")
      .select("id, client_id, admin_id")
      .eq("id", conversation_id)
      .single();

    if (convErr || !conv) {
      console.error("[v0] Conversation fetch error:", convErr);
      return NextResponse.json({ error: "Conversa não encontrada" }, { status: 404 });
    }

    if (conv.client_id !== user.id && conv.admin_id !== user.id) {
      return NextResponse.json({ error: "Usuário não faz parte desta conversa" }, { status: 403 });
    }

    // Insere mensagem
    const { data: message, error } = await supabase
      .from("conversation_messages")
      .insert({
        conversation_id: conversation_id,
        sender_id: user.id,
        content,
      })
      .select()
      .single();

    if (error) {
      console.error("[v0] Error creating message:", error);
      return NextResponse.json({ error: "Erro ao enviar mensagem" }, { status: 500 });
    }

    // Atualiza last_message_at na conversa
    await supabase
      .from("conversations")
      .update({ last_message_at: new Date().toISOString() })
      .eq("id", conversation_id);

    return NextResponse.json({ message });
  } catch (error) {
    console.error("[v0] Messages API error:", error);
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 });
  }
}
