import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: Request) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const data = await request.json()
    const { title, description, priority, user_id } = data

    if (user_id !== user.id) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 403 })
    }

    const { data: ticket, error } = await supabase
      .from("tickets")
      .insert({
        user_id,
        title,
        description,
        priority,
        status: "open",
      })
      .select()
      .single()

    if (error) {
      console.error("[v0] Error creating ticket:", error)
      return NextResponse.json({ error: "Erro ao criar ticket" }, { status: 500 })
    }

    return NextResponse.json({ ticket })
  } catch (error) {
    console.error("[v0] Tickets API error:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
