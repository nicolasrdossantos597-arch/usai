import { Navbar } from "@/components/shared/navbar"
import { Footer } from "@/components/shared/footer"
import { SolutionsHero } from "@/components/solucoes/solutions-hero"
import { SolutionsList } from "@/components/solucoes/solutions-list"
import { ProcessSection } from "@/components/solucoes/process-section"
import { TechStack } from "@/components/solucoes/tech-stack"

export default function SolucoesPage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <SolutionsHero />
      <SolutionsList />
      <ProcessSection />
      <TechStack />
      <Footer />
    </main>
  )
}
