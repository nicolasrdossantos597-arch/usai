import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DashboardContentEditor } from "@/components/admin/dashboard-content-editor"

export default async function DashboardConfigPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.role !== "admin") {
    redirect("/dashboard")
  }

  const { data: dashboardContent } = await supabase
    .from("dashboard_content")
    .select("*")
    .order("display_order", { ascending: true })

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="border-b bg-white">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold text-gray-900">Configurar Dashboard dos Clientes</h1>
          <p className="mt-2 text-gray-600">Personalize o que os clientes veem no dashboard</p>
        </div>
      </div>

      <main className="container mx-auto px-4 py-8">
        <DashboardContentEditor initialContent={dashboardContent || []} />
      </main>
    </div>
  )
}
