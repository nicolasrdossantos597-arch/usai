import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { AdminHeader } from "@/components/admin/header"
import { AdminTicketChat } from "@/components/admin/admin-ticket-chat"
import { AdminTicketDetails } from "@/components/admin/admin-ticket-details"

export default async function AdminTicketPage({ params }: { params: { id: string } }) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.role !== "admin") {
    redirect("/dashboard")
  }

  const { data: ticket } = await supabase
    .from("tickets")
    .select("*, user:profiles!user_id(*), assigned_user:profiles!assigned_to(*)")
    .eq("id", params.id)
    .single()

  if (!ticket) {
    redirect("/admin/tickets")
  }

  const { data: messages } = await supabase
    .from("messages")
    .select("*, sender:profiles!sender_id(*)")
    .eq("ticket_id", ticket.id)
    .order("created_at", { ascending: true })

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader profile={profile} />
      <main className="container mx-auto px-4 py-8">
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <AdminTicketChat ticket={ticket} initialMessages={messages || []} currentUserId={user.id} />
          </div>
          <div>
            <AdminTicketDetails ticket={ticket} />
          </div>
        </div>
      </main>
    </div>
  )
}
