import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { AdminHeader } from "@/components/admin/header"
import { AdminTicketsList } from "@/components/admin/admin-tickets-list"

export default async function AdminTicketsPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.role !== "admin") {
    redirect("/dashboard")
  }

  const { data: tickets } = await supabase
    .from("tickets")
    .select("*, user:profiles!user_id(*), assigned_user:profiles!assigned_to(*)")
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader profile={profile} />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="mb-2 text-3xl font-bold text-gray-900">Gerenciar Tickets</h1>
          <p className="text-gray-600">Visualize e gerencie todos os tickets de suporte dos clientes.</p>
        </div>

        <AdminTicketsList tickets={tickets || []} />
      </main>
    </div>
  )
}
