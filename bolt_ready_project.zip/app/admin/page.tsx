import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { AdminHeader } from "@/components/admin/header"
import { AdminStats } from "@/components/admin/stats"
import { RecentTicketsAdmin } from "@/components/admin/recent-tickets"
import { RecentContactsAdmin } from "@/components/admin/recent-contacts"

export default async function AdminPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.role !== "admin") {
    redirect("/dashboard")
  }

  // Get stats
  const { count: totalClients } = await supabase
    .from("profiles")
    .select("*", { count: "exact", head: true })
    .eq("role", "client")

  const { count: openTickets } = await supabase
    .from("tickets")
    .select("*", { count: "exact", head: true })
    .in("status", ["open", "in_progress"])

  const { count: totalTickets } = await supabase.from("tickets").select("*", { count: "exact", head: true })

  const { count: pendingContacts } = await supabase
    .from("contact_submissions")
    .select("*", { count: "exact", head: true })
    .eq("is_processed", false)

  // Get recent tickets
  const { data: recentTickets } = await supabase
    .from("tickets")
    .select("*, user:profiles!user_id(*), assigned_user:profiles!assigned_to(*)")
    .order("created_at", { ascending: false })
    .limit(5)

  // Get recent contacts
  const { data: recentContacts } = await supabase
    .from("contact_submissions")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(5)

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader profile={profile} />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="mb-2 text-3xl font-bold text-gray-900">Painel Administrativo</h1>
          <p className="text-gray-600">Gerencie clientes, tickets e toda a operação da UAI Sistemas.</p>
        </div>

        <AdminStats
          totalClients={totalClients || 0}
          openTickets={openTickets || 0}
          totalTickets={totalTickets || 0}
          pendingContacts={pendingContacts || 0}
        />

        <div className="mt-8 grid gap-8 lg:grid-cols-2">
          <RecentTicketsAdmin tickets={recentTickets || []} />
          <RecentContactsAdmin contacts={recentContacts || []} />
        </div>
      </main>
    </div>
  )
}
