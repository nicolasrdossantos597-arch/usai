import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileText, Download, CreditCard } from "lucide-react"

export default async function InvoicesPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/login")
  }

  // Mock invoices data - you can replace this with actual database queries
  const invoices = [
    {
      id: "1",
      invoice_number: "INV-2025-001",
      date: "2025-01-15",
      amount: 2500.0,
      status: "paid",
      description: "Desenvolvimento de Sistema Web",
    },
    {
      id: "2",
      invoice_number: "INV-2024-045",
      date: "2024-12-15",
      amount: 2500.0,
      status: "paid",
      description: "Desenvolvimento de Sistema Web",
    },
    {
      id: "3",
      invoice_number: "INV-2024-032",
      date: "2024-11-15",
      amount: 2500.0,
      status: "paid",
      description: "Desenvolvimento de Sistema Web",
    },
  ]

  const statusColors: Record<string, string> = {
    paid: "bg-green-100 text-green-700",
    pending: "bg-yellow-100 text-yellow-700",
    overdue: "bg-red-100 text-red-700",
  }

  const statusLabels: Record<string, string> = {
    paid: "Paga",
    pending: "Pendente",
    overdue: "Vencida",
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50/30 to-cyan-50/30">
      <DashboardHeader profile={profile} />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="mb-2 text-4xl font-bold text-gray-900">Faturas</h1>
          <p className="text-lg text-gray-600">Visualize e baixe suas faturas</p>
        </div>

        {/* Summary cards */}
        <div className="grid gap-6 mb-8 md:grid-cols-3">
          <Card className="border-0 shadow-lg shadow-gray-200/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Pago</p>
                  <p className="mt-2 text-3xl font-bold text-gray-900">R$ 7.500,00</p>
                </div>
                <div className="rounded-2xl bg-green-50 p-3">
                  <CreditCard className="h-6 w-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg shadow-gray-200/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Faturas Pagas</p>
                  <p className="mt-2 text-3xl font-bold text-gray-900">3</p>
                </div>
                <div className="rounded-2xl bg-blue-50 p-3">
                  <FileText className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg shadow-gray-200/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Pendentes</p>
                  <p className="mt-2 text-3xl font-bold text-gray-900">0</p>
                </div>
                <div className="rounded-2xl bg-yellow-50 p-3">
                  <FileText className="h-6 w-6 text-yellow-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Invoices list */}
        <Card className="border-0 shadow-lg shadow-gray-200/50">
          <CardHeader>
            <CardTitle>Histórico de Faturas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {invoices.map((invoice) => (
                <div
                  key={invoice.id}
                  className="flex items-center justify-between rounded-lg border border-gray-200 p-4 hover:border-blue-200 hover:bg-blue-50/50"
                >
                  <div className="flex items-center gap-4 flex-1">
                    <div className="rounded-lg bg-blue-100 p-3">
                      <FileText className="h-6 w-6 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-semibold text-gray-900">{invoice.invoice_number}</p>
                        <span
                          className={`rounded-full px-2 py-0.5 text-xs font-medium ${statusColors[invoice.status]}`}
                        >
                          {statusLabels[invoice.status]}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">{invoice.description}</p>
                      <p className="text-xs text-gray-500 mt-1">{new Date(invoice.date).toLocaleDateString("pt-BR")}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-xl font-bold text-gray-900">
                        {invoice.amount.toLocaleString("pt-BR", {
                          style: "currency",
                          currency: "BRL",
                        })}
                      </p>
                    </div>
                    <Button variant="outline" size="icon">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
