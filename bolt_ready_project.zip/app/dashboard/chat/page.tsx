import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DashboardHeader } from "@/components/dashboard/header"
import { ChatInterface } from "@/components/chat/chat-interface"

export default async function ChatPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/login")
  }

  // Get user's chat rooms
  const { data: chatRooms } = await supabase
    .from("chat_room_members")
    .select("chat_room_id, chat_rooms(*)")
    .eq("user_id", user.id)

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50/30 to-cyan-50/30">
      <DashboardHeader profile={profile} />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="mb-2 text-4xl font-bold text-gray-900">Chat</h1>
          <p className="text-lg text-gray-600">Converse em tempo real com nossa equipe</p>
        </div>

        <ChatInterface profile={profile} chatRooms={chatRooms || []} />
      </main>
    </div>
  )
}
