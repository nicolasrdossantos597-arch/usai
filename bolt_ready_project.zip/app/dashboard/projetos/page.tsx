import { redirect } from "next/navigation"
import Link from "next/link"
import { createClient } from "@/lib/supabase/server"
import { DashboardHeader } from "@/components/dashboard/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Plus, FolderKanban } from "lucide-react"

export default async function ProjectsPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/login")
  }

  const { data: projects } = await supabase
    .from("projects")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  const statusLabels: Record<string, string> = {
    planning: "Planejamento",
    in_progress: "Em Andamento",
    testing: "Em Testes",
    completed: "Concluído",
    on_hold: "Pausado",
  }

  const statusColors: Record<string, string> = {
    planning: "bg-yellow-100 text-yellow-700",
    in_progress: "bg-blue-100 text-blue-700",
    testing: "bg-purple-100 text-purple-700",
    completed: "bg-green-100 text-green-700",
    on_hold: "bg-gray-100 text-gray-700",
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50/30 to-cyan-50/30">
      <DashboardHeader profile={profile} />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="mb-2 text-4xl font-bold text-gray-900">Meus Projetos</h1>
            <p className="text-lg text-gray-600">Gerencie e acompanhe todos os seus projetos</p>
          </div>
          <Button asChild size="lg" className="gap-2">
            <Link href="/dashboard/projetos/novo">
              <Plus className="h-5 w-5" />
              Novo Projeto
            </Link>
          </Button>
        </div>

        {!projects || projects.length === 0 ? (
          <Card className="border-0 shadow-lg">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <FolderKanban className="mb-4 h-16 w-16 text-gray-400" />
              <h3 className="mb-2 text-xl font-semibold text-gray-900">Nenhum projeto ainda</h3>
              <p className="mb-6 text-gray-600">Comece criando seu primeiro projeto</p>
              <Button asChild>
                <Link href="/dashboard/projetos/novo">
                  <Plus className="mr-2 h-5 w-5" />
                  Criar Primeiro Projeto
                </Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {projects.map((project) => (
              <Link key={project.id} href={`/dashboard/projetos/${project.id}`}>
                <Card className="h-full border-0 shadow-lg shadow-gray-200/50 transition-all hover:shadow-xl hover:scale-[1.02]">
                  <CardContent className="p-6">
                    <div className="mb-4 flex items-start justify-between">
                      <div className="rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 p-3">
                        <FolderKanban className="h-6 w-6 text-white" />
                      </div>
                      <span
                        className={`rounded-full px-2.5 py-1 text-xs font-medium ${
                          statusColors[project.status] || statusColors.planning
                        }`}
                      >
                        {statusLabels[project.status] || project.status}
                      </span>
                    </div>
                    <h3 className="mb-2 text-xl font-bold text-gray-900">{project.name}</h3>
                    {project.description && (
                      <p className="mb-4 text-sm text-gray-600 line-clamp-2">{project.description}</p>
                    )}
                    <div className="mt-4">
                      <div className="mb-2 flex items-center justify-between text-sm">
                        <span className="text-gray-600">Progresso</span>
                        <span className="font-semibold text-gray-900">{project.progress}%</span>
                      </div>
                      <Progress value={project.progress} className="h-2" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
