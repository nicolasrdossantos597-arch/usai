import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DashboardHeader } from "@/components/dashboard/header"
import { TicketChat } from "@/components/suporte/ticket-chat"
import { TicketDetails } from "@/components/suporte/ticket-details"

export default async function TicketPage({ params }: { params: { id: string } }) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/login")
  }

  const { data: ticket } = await supabase
    .from("tickets")
    .select("*, user:profiles!user_id(*), assigned_user:profiles!assigned_to(*)")
    .eq("id", params.id)
    .eq("user_id", user.id)
    .single()

  if (!ticket) {
    redirect("/dashboard/suporte")
  }

  const { data: messages } = await supabase
    .from("messages")
    .select("*, sender:profiles!sender_id(*)")
    .eq("ticket_id", ticket.id)
    .order("created_at", { ascending: true })

  return (
    <div className="min-h-screen bg-gray-50">
      <DashboardHeader profile={profile} />
      <main className="container mx-auto px-4 py-8">
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <TicketChat ticket={ticket} initialMessages={messages || []} currentUserId={user.id} />
          </div>
          <div>
            <TicketDetails ticket={ticket} />
          </div>
        </div>
      </main>
    </div>
  )
}
