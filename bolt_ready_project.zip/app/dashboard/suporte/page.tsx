import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DashboardHeader } from "@/components/dashboard/header"
import { TicketsList } from "@/components/suporte/tickets-list"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"

export default async function SuportePage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/login")
  }

  const { data: tickets } = await supabase
    .from("tickets")
    .select("*, user:profiles!user_id(*), assigned_user:profiles!assigned_to(*)")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen bg-gray-50">
      <DashboardHeader profile={profile} />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="mb-2 text-3xl font-bold text-gray-900">Meus Tickets de Suporte</h1>
            <p className="text-gray-600">Gerencie seus chamados e converse com nossa equipe de suporte.</p>
          </div>
          <Button asChild>
            <Link href="/dashboard/suporte/novo">
              <Plus className="mr-2 h-4 w-4" />
              Novo Ticket
            </Link>
          </Button>
        </div>

        <TicketsList tickets={tickets || []} />
      </main>
    </div>
  )
}
