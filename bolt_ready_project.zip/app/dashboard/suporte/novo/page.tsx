import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DashboardHeader } from "@/components/dashboard/header"
import { CreateTicketForm } from "@/components/suporte/create-ticket-form"

export default async function NovoTicketPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/login")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <DashboardHeader profile={profile} />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="mb-2 text-3xl font-bold text-gray-900">Criar Novo Ticket</h1>
          <p className="text-gray-600">Descreva seu problema ou dúvida e nossa equipe entrará em contato.</p>
        </div>

        <CreateTicketForm userId={user.id} />
      </main>
    </div>
  )
}
