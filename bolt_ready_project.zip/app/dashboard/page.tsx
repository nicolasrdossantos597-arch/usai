import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DashboardHeader } from "@/components/dashboard/header"
import { StatsGrid } from "@/components/dashboard/stats-grid"
import { ActivityFeed } from "@/components/dashboard/activity-feed"
import { QuickActions } from "@/components/dashboard/quick-actions"
import { DynamicDashboardSection } from "@/components/dashboard/dynamic-dashboard-section"

export default async function DashboardPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/login")
  }

  const { count: activeProjectsCount } = await supabase
    .from("projects")
    .select("*", { count: "exact", head: true })
    .eq("user_id", user.id)
    .in("status", ["planning", "in_progress", "testing"])

  const { count: openTicketsCount } = await supabase
    .from("tickets")
    .select("*", { count: "exact", head: true })
    .eq("user_id", user.id)
    .in("status", ["open", "in_progress"])

  const { count: unreadMessagesCount } = await supabase
    .from("conversation_messages")
    .select("*", { count: "exact", head: true })
    .eq("is_read", false)
    .neq("sender_id", user.id)

  const { data: recentActivity } = await supabase
    .from("activity_log")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(5)

  const { data: dashboardContent } = await supabase
    .from("dashboard_content")
    .select("*")
    .eq("is_visible", true)
    .order("display_order", { ascending: true })

  const welcomeSection = dashboardContent?.find((s) => s.section === "welcome")

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50/30 to-cyan-50/30">
      <DashboardHeader profile={profile} />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="mb-2 text-4xl font-bold text-gray-900">
            {welcomeSection?.title || `Olá, ${profile.full_name.split(" ")[0]} 👋`}
          </h1>
          <p className="text-lg text-gray-600">
            {welcomeSection?.description || "Aqui está um resumo das suas atividades."}
          </p>
        </div>

        <StatsGrid
          activeProjects={activeProjectsCount || 0}
          openTickets={openTicketsCount || 0}
          unreadMessages={unreadMessagesCount || 0}
        />

        <div className="mt-8">
          <QuickActions />
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <DynamicDashboardSection userId={user.id} sectionType="projects" />
          </div>
          <div className="lg:col-span-1">
            <ActivityFeed activities={recentActivity || []} />
          </div>
        </div>
      </main>
    </div>
  )
}
