import { Navbar } from "@/components/shared/navbar"
import { Footer } from "@/components/shared/footer"
import { ContactHero } from "@/components/contato/contact-hero"
import { ContactForm } from "@/components/contato/contact-form"
import { ContactInfo } from "@/components/contato/contact-info"

export default function ContatoPage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <ContactHero />
      <div className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12">
            <ContactForm />
            <ContactInfo />
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
