import { Navbar } from "@/components/shared/navbar"
import { Footer } from "@/components/shared/footer"
import { HeroSection } from "@/components/home/hero-section"
import { ClientLogos } from "@/components/home/client-logos"
import { HowItWorks } from "@/components/home/how-it-works"
import { Benefits } from "@/components/home/benefits"
import { WhyChooseUs } from "@/components/home/why-choose-us"
import { Testimonials } from "@/components/home/testimonials"
import { CompetitiveAdvantages } from "@/components/home/competitive-advantages"
import { FinalCTA } from "@/components/home/final-cta"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-20">
        <HeroSection />
        <ClientLogos />
        <HowItWorks />
        <Benefits />
        <WhyChooseUs />
        <Testimonials />
        <CompetitiveAdvantages />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  )
}
